# ASCENSION v0.7 Native Foundation

This project is the migration bridge from the v0.6 WebView prototype to a future-proof native Android app **without requiring a paid server, subscription, Firebase project, Supabase instance, or ASCENSION account**.

## Why this is a bridge instead of a rewrite

A one-shot rewrite would create the biggest possible risk: losing a working app and months of Player data while dozens of features are reimplemented at once.

v0.7 uses a strangler migration:

1. **Keep the proven v0.6 interface running inside a normal Kotlin Android app.**
2. **Add native capabilities immediately**: local notifications, app-private progress photos, Player Vault backup, Room persistence.
3. **Dual-write the complete v0.6 state into the native layer.**
4. **Preserve the raw v0.6 JSON byte-for-byte** so future migrations can recover fields that v0.7 does not normalize yet.
5. **Port screens from WebView to Compose one at a time** while the old screen remains a fallback.
6. Remove the WebView only after native feature parity and migration tests pass.

This gives ASCENSION a safe path from prototype to long-term app without stopping feature development.

## Identity and update safety

- Application ID: `com.ascension.personal`
- Native foundation versionCode: `700`
- Target SDK: Android 16 / API 36
- minSdk: 26
- **Release builds must be signed with the same ASCENSION signing key used by v0.3+** if you want Android to install this over the existing app.
- Debug builds intentionally use `com.ascension.personal.dev` so they cannot overwrite the real Player data while testing.

## What is already implemented in this foundation

### Transitional native shell
The existing v0.6 app is bundled at the same asset URL (`file:///android_asset/index.html`) inside a standard `ComponentActivity`/Compose app. Keeping the same package and WebView origin is designed to allow the existing WebView localStorage to remain available after an in-place signed update.

### Room persistence
`ascension.db` stores normalized Player data plus a full `legacy_snapshots` record containing the entire v0.6 state JSON and SHA-256 checksum.

**Never add `fallbackToDestructiveMigration()` to production.** Every future schema change gets an explicit migration and migration test.

### Dual-write migration
Every legacy `save()` still writes localStorage and also sends the complete state to `ASCENSION_NATIVE.persistState()`. Native code debounces the writes, hashes the state, stores the raw snapshot, and normalizes core records into Room.

### Local dungeon notifications
When the v0.6 dungeon system starts an expedition it schedules a WorkManager job. The expedition calculation remains timestamp-based; the notification only tells the Player when it is time to return.

No push server is required.

### Native progress-photo capture
Daily Evidence can call the Android camera. Images are written to app-private `files/progress_photos/`, hashed, and indexed in Room.

The app requests no broad photo-library permission.

### Player Vault
`EXPORT BACKUP` can open Android's system document picker and save an `.ascension` portable ZIP to any document provider the user chooses.

The archive contains:

- `manifest.json`
- complete v0.6 state JSON
- progress-photo metadata
- app-private progress photos
- SHA-256 state integrity value

The user can choose local storage, Google Drive, OneDrive, or another installed Android document provider without ASCENSION operating a cloud backend.

### Core game engines
Pure domain code has been separated for:

- progression / combat power
- equipment stat requirements
- deterministic dungeon outcomes
- readiness rules

The design rule is preserved: real-world progress dominates; equipment bonuses are capped.

## The migration order

### Phase 1 — Safety foundation (v0.7)
- [x] Same package identity
- [x] Native Android application shell
- [x] Preserve legacy WebView state
- [x] Dual-write full Player state
- [x] Raw legacy snapshot with checksum
- [x] Room schema v1
- [x] local expedition notification engine
- [x] app-private progress-photo capture
- [x] system document Player Vault export/import foundation
- [x] zero-network-permission core
- [ ] Build/sign/install on a physical Android device
- [ ] Run migration against a real existing v0.6 Player
- [ ] Add Room migration instrumentation tests to CI once a schema v2 exists

### Phase 2 — Native data authority
Move one domain at a time from JavaScript/localStorage to Room. Recommended order:

1. Player/Profile
2. Chronicle and event ledger
3. bodyweight and benchmark history
4. workouts/exercise sets
5. quests/Legendary/Life quests
6. nutrition and weekly food plan
7. World/dungeons/equipment
8. progress photos

During this phase, native data becomes the source of truth and the legacy page becomes a renderer only.

### Phase 3 — Native Compose screens
Port screens one at a time:

1. **SYSTEM** — highest daily usage, best first target
2. **TRAIN**
3. **FUEL**
4. **JOURNEY**
5. **PLAYER**

Every screen replacement should keep the old WebView route available behind a developer flag until native parity tests pass.

### Phase 4 — Remove WebView
Only remove `assets/index.html` after:

- fresh install works
- v0.6 signed upgrade works
- backup/restore works across two devices
- database migrations have tests
- all five native screens have parity
- dungeon timers survive reboot/process death
- photos survive backup/restore

## Data rule: event history first

Do not store only the current result. Keep events that created it.

Example:

- `2026-09-13 workout_completed`
- `2026-09-13 bench_set 185x8 @1RIR`
- `2026-09-15 life_quest_completed`
- `2026-09-18 dungeon_cleared`

Derived values such as Level, Rank, statistics, Chronicle summaries, yearly recaps, and future formulas can then be rebuilt without rewriting history.

## Zero-cost architecture

| Need | $0 solution |
|---|---|
| Database | Room / SQLite on device |
| Settings | DataStore |
| UI | Jetpack Compose |
| local notifications | WorkManager + NotificationManager |
| photos | app-private files + Camera/Photo Picker |
| backup | Storage Access Framework `.ascension` archive |
| optional user cloud | user's own Drive/OneDrive document provider |
| builds | local Android Studio or GitHub Actions free allowance |
| source control | GitHub private repository |
| game engine | deterministic local Kotlin |
| analytics | none required |
| accounts | none required |
| server | none required |

## Features that should stay optional-provider based

Do not make the core app depend on:

- AI food-photo recognition
- AI face-to-3D avatar generation
- generated infinite lore
- live multi-device sync

Those can later implement interfaces/providers. If a provider becomes paid or disappears, ASCENSION must continue working.

## Build

Required:

- JDK 17
- Android SDK Platform 36
- Build Tools 36.0.0
- Gradle 8.13

From the project root:

```bash
gradle testDebugUnitTest
gradle assembleDebug
```

The GitHub Actions workflow installs those tools automatically.

## Release signing

See `SIGNING_AND_UPDATES.md`. Do **not** commit a keystore or passwords into Git.

## Important status

This package is a **native foundation source tree**, not a claim that the whole v0.6 product has already been rewritten in Compose. Its job is to make that rewrite safe and incremental while immediately solving the largest architectural blockers.
