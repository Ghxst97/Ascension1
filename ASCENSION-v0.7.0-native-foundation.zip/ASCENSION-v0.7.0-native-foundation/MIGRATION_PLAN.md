# ASCENSION Migration Plan — exact order

## Gate 0: protect the current Player

1. Open v0.6.
2. Create a Player Capsule / JSON backup.
3. Keep the v0.6 APK somewhere safe.
4. Never uninstall the real app before a signed native upgrade has successfully imported the Player.

## Gate 1: build v0.7 as a separate debug app

The debug build uses package `com.ascension.personal.dev` and therefore cannot damage v0.6.

1. Build `assembleDebug`.
2. Install alongside v0.6.
3. Test new camera, backup picker, notifications, fold/unfold behavior.
4. Because it is a separate package, it will not see the real v0.6 WebView localStorage. Use a test backup for debug testing.

## Gate 2: build signed release with the existing key

1. Set the existing ASCENSION keystore in CI or local Gradle environment.
2. Confirm release applicationId is `com.ascension.personal`.
3. Confirm release versionCode is > the installed app. Foundation uses 700.
4. Build `assembleRelease`.
5. Do not uninstall v0.6.
6. Install the release APK as an update.

Expected result: Android preserves the app's data directory because package and signing identity match.

## Gate 3: first-run legacy import

1. v0.7 loads the bundled asset at `file:///android_asset/index.html`.
2. Existing WebView localStorage should contain `ascension.v030.state`.
3. Normal v0.6 initialization calls `save()`.
4. Patched `save()` also calls `ASCENSION_NATIVE.persistState(rawJson)`.
5. Native code hashes and imports the state into Room.
6. `legacy_snapshots` keeps the complete source JSON even if some fields are not yet normalized.

Verification checklist:

- Player name, XP, streak, stones match.
- attributes match.
- weight history count matches.
- notes match.
- Chronicle count matches.
- nutrition history count matches.
- equipped weapon/armor are preserved.
- v0.6 interface still behaves normally.

If any check fails, stop the migration and continue using v0.6. The old localStorage data has not been deleted.

## Gate 4: native capabilities

### Expedition notification
Deploy a short test dungeon. Close ASCENSION. Verify the local notification appears after the finish time. Opening it should return to ASCENSION; the existing dungeon report remains authoritative.

### Progress photo
Use Daily Evidence. Confirm:

- camera opens
- no broad gallery permission is requested
- photo is in app-private storage
- Room contains photo metadata + SHA-256
- UI marks the day after native callback

### Player Vault
Export an `.ascension` file to a user-selected document provider. Restore it into a clean debug install and verify the state checksum before importing.

## Gate 5: make Room authoritative one feature at a time

Never flip the entire app at once. For each domain:

1. Add normalized entities/DAO operations.
2. Import that domain from raw legacy state.
3. Write unit tests for formulas.
4. Write a migration/import test using a real anonymized v0.6 state fixture.
5. Make native repository source of truth.
6. Make legacy JavaScript read from native bridge for that domain.
7. Verify parity for at least one full week of use.
8. Only then delete duplicated JavaScript storage logic for that domain.

## Gate 6: Compose screen migration

Port SYSTEM first. A native System screen proves:

- Room flows update live
- adaptive Fold layout works
- typography and density improve
- haptics/animations can be native
- navigation state survives configuration changes

Then Train -> Fuel -> Journey -> Player.

## Gate 7: retire legacy WebView

Do not remove it because the new UI "looks done." Remove it only after all data, backup, migration, photos, dungeons, notifications, and the five screens have automated tests and real-device verification.
