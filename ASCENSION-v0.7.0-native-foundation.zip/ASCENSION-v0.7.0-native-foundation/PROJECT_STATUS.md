# Project status

## Completed in this package

- Native Kotlin/Compose Android project shell
- same production application ID as existing ASCENSION
- target API 36 / min API 26
- current v0.6 HTML preserved as migration fallback
- JavaScript/native bridge
- Room schema v1 + raw legacy snapshot preservation
- v0.6 JSON -> core Room mapping
- local expedition notification scheduler
- native camera Daily Evidence flow
- app-private progress-photo storage + hashes
- Player Vault `.ascension` export/restore foundation
- portable backup integrity checks
- zero-network manifest (no INTERNET permission)
- separated progression/equipment/dungeon/readiness engines
- GitHub Actions build workflow
- release-signing hooks that keep secrets out of source
- migration/signing/phone-only documentation
- legacy JS syntax validation
- pure Kotlin readiness engine smoke test

## Not yet completed

- Full native Compose rewrite of all five screens
- Room as authoritative source for every v0.6 domain
- side-by-side photo comparison UI
- biometric lock for photos
- exact v0.6 -> Room normalization for every individual exercise set/meal/world field
- physical install test on the user's Fold
- signed release APK compilation in this environment

The container used to create this package does not currently contain the Android SDK/Gradle distribution required to compile the native Android application. The included GitHub Actions workflow is intended to perform that build at no hosting cost to ASCENSION.
