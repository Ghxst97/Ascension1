# Phone/iPad-only build path

You do not need a PC once the project is in GitHub.

## Easiest long-term flow

1. Keep the ASCENSION project in a private GitHub repository.
2. Every push to `main` runs `.github/workflows/build-apk.yml`.
3. GitHub installs JDK/Android SDK/Gradle on its runner.
4. Tests run.
5. GitHub builds the APK.
6. Open the repository in Safari/Chrome/GitHub app -> Actions -> latest run -> Artifacts.
7. Download the APK to the Fold and install it.

This avoids needing Android Studio on your phone.

## Until GitHub access is connected to ChatGPT

The source ZIP can be stored in Files/Drive as the canonical handoff. Once repository access works, the entire tree should be committed rather than uploading generated APKs as the source of truth.

## Testing rule

- Debug APK: safe side-by-side test app; does not use the real package/profile.
- Release APK signed with the existing key: actual update path.
- Before every migration milestone: export a Player Vault backup.
