# Architecture boundary

ASCENSION should keep three layers conceptually separate:

## REAL LIFE
Authoritative observations and actions:
- workout sessions and sets
- weight/benchmark history
- nutrition
- sleep/readiness inputs
- progress photos
- Life/Legendary quest completion
- notes

## PLAYER
Derived representation:
- XP / level / rank
- attributes
- class/archetype
- unlocked skills
- equipment eligibility
- cosmetics
- statistical reference results

## WORLD
Game expression:
- gates
- dungeons
- bosses
- deterministic combat simulation
- loot
- Realm state
- lore discoveries

Dependency direction:

`REAL LIFE -> PLAYER -> WORLD`

World outcomes must never create fake real-world progress. Gear may affect game outcomes but cannot increase a user's recorded bench, 5K, workout adherence, nutrition, or recovery score.

## UI principle

Underlying systems may become deep. The first screen should become simpler.

The normal System view should answer only:

1. What is my Main Quest?
2. What support objectives matter today?
3. Is there one meaningful event waiting for me?
4. Am I ready to train normally?

Everything else uses progressive disclosure.
