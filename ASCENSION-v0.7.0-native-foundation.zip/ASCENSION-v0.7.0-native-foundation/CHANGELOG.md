# v0.7.0 Native Foundation

This is an architectural migration milestone rather than a feature-heavy release.

### Added
- Kotlin/Compose Android shell
- Room database foundation
- full raw v0.6 state snapshot preservation
- native/local dungeon completion notifications
- native Daily Evidence camera capture
- app-private progress photo vault storage
- Player Vault `.ascension` document export/restore
- deterministic domain engine separation
- zero-cost GitHub Actions build pipeline

### Migration safety
- same production package: `com.ascension.personal`
- release versionCode 700
- debug package is intentionally separate (`.dev`)
- legacy asset path remains `file:///android_asset/index.html`
- WebView state remains the fallback until Room/Compose parity is complete
