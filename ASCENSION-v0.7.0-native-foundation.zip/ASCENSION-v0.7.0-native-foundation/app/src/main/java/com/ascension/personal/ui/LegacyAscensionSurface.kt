package com.ascension.personal.ui

import android.annotation.SuppressLint
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.ascension.personal.migration.AscensionNativeBridge

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LegacyAscensionSurface(
    bridge: AscensionNativeBridge,
    onWebView: (WebView) -> Unit
) {
    var web: WebView? = null
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { context ->
            WebView(context).apply {
                web = this
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.allowFileAccess = true
                settings.setSupportZoom(false)
                overScrollMode = WebView.OVER_SCROLL_NEVER
                webViewClient = WebViewClient()
                webChromeClient = WebChromeClient()
                addJavascriptInterface(bridge, "ASCENSION_NATIVE")
                loadUrl("file:///android_asset/index.html")
                onWebView(this)
            }
        }
    )
    DisposableEffect(Unit) {
        onDispose {
            web?.removeJavascriptInterface("ASCENSION_NATIVE")
            web?.destroy()
        }
    }
}
