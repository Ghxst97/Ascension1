package com.ascension.personal

import android.app.Application
import com.ascension.personal.data.db.AscensionDatabase
import com.ascension.personal.notifications.NotificationChannels

class AscensionApplication : Application() {
    val database: AscensionDatabase by lazy { AscensionDatabase.create(this) }

    override fun onCreate() {
        super.onCreate()
        NotificationChannels.ensureCreated(this)
    }
}
