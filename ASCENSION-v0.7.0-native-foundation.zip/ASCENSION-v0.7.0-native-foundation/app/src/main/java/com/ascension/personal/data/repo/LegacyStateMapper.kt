package com.ascension.personal.data.repo

import com.ascension.personal.data.db.*
import kotlinx.serialization.json.*
import java.security.MessageDigest
import java.time.LocalDate
import java.time.ZoneId

object LegacyStateMapper {
    data class Mapped(
        val player: PlayerEntity,
        val attributes: List<AttributeEntity>,
        val weights: List<WeightEntryEntity>,
        val notes: List<NoteEntity>,
        val chronicle: List<ChronicleEntity>,
        val nutrition: List<NutritionDayEntity>,
        val equipment: List<EquipmentEntity>,
        val snapshot: LegacyStateSnapshotEntity
    )

    private val json = Json { ignoreUnknownKeys = true }

    fun map(raw: String): Mapped {
        val root = json.parseToJsonElement(raw).jsonObject
        val profile = root["profile"]?.jsonObject ?: buildJsonObject { }
        val attrs = root["attributes"]?.jsonObject ?: buildJsonObject { }
        val inv = root["inventory"]?.jsonObject ?: buildJsonObject { }
        val avatar = root["avatar"]?.jsonObject ?: buildJsonObject { }

        fun JsonObject.str(key: String) = this[key]?.jsonPrimitive?.contentOrNull
        fun JsonObject.int(key: String) = this[key]?.jsonPrimitive?.intOrNull
        fun JsonObject.double(key: String) = this[key]?.jsonPrimitive?.doubleOrNull
        fun JsonObject.bool(key: String) = this[key]?.jsonPrimitive?.booleanOrNull

        val hFt = profile.int("heightFt") ?: profile.str("heightFt")?.toIntOrNull()
        val hIn = profile.int("heightIn") ?: profile.str("heightIn")?.toIntOrNull()
        val startDate = root["journeyStartDate"]?.jsonPrimitive?.contentOrNull
        val player = PlayerEntity(
            name = profile.str("name").orEmpty(),
            age = profile.int("age") ?: profile.str("age")?.toIntOrNull(),
            heightInches = if (hFt != null) hFt * 12 + (hIn ?: 0) else null,
            weightLb = profile.double("weight") ?: profile.str("weight")?.toDoubleOrNull(),
            sex = profile.str("sex") ?: "male",
            goal = profile.str("goal") ?: "muscle",
            experience = profile.str("experience") ?: "beginner",
            journeyStartedAt = startDate?.let(::dateToEpoch),
            xp = root["xp"]?.jsonPrimitive?.intOrNull ?: 0,
            streak = root["streak"]?.jsonPrimitive?.intOrNull ?: 0,
            bestStreak = root["bestStreak"]?.jsonPrimitive?.intOrNull ?: 0,
            revivalStones = root["stones"]?.jsonPrimitive?.intOrNull ?: 2
        )

        val attributeRows = listOf("strength","physique","mobility","endurance","recovery","discipline","connection","experience").map { key ->
            AttributeEntity(key, attrs[key]?.jsonPrimitive?.doubleOrNull ?: 10.0)
        }

        val weightRows = root["weights"]?.jsonArray?.mapIndexedNotNull { i, el ->
            val o = el.jsonObject
            val value = o["value"]?.jsonPrimitive?.doubleOrNull ?: return@mapIndexedNotNull null
            val date = o["date"]?.jsonPrimitive?.contentOrNull ?: return@mapIndexedNotNull null
            WeightEntryEntity("legacy-$date-$i", dateToEpoch(date), value, "legacy-v060")
        }.orEmpty()

        val noteRows = root["notes"]?.jsonObject?.map { (date, value) -> NoteEntity(date, value.jsonPrimitive.content) }.orEmpty()

        val chronicleRows = root["chronicle"]?.jsonArray?.mapIndexedNotNull { i, el ->
            val o = el.jsonObject
            val id = o.str("id") ?: "legacy-chronicle-$i"
            val date = o.str("date") ?: LocalDate.now().toString()
            ChronicleEntity(
                id = id,
                occurredAt = dateToEpoch(date),
                grade = o.str("grade") ?: "common",
                title = o.str("title") ?: "ASCENSION Event",
                detail = o.str("detail") ?: "",
                payloadJson = o.toString()
            )
        }.orEmpty()

        val nutritionRows = root["nutritionHistory"]?.jsonObject?.mapNotNull { (date, el) ->
            val o = el.jsonObject
            NutritionDayEntity(
                date = date,
                calories = o["k"]?.jsonPrimitive?.intOrNull ?: 0,
                proteinG = o["p"]?.jsonPrimitive?.intOrNull ?: 0,
                carbsG = o["c"]?.jsonPrimitive?.intOrNull ?: 0,
                fatG = o["f"]?.jsonPrimitive?.intOrNull ?: 0,
                meals = o["meals"]?.jsonPrimitive?.intOrNull ?: 0
            )
        }.orEmpty()

        val weapons = inv["weapons"]?.jsonArray?.mapNotNull { it.jsonPrimitive.contentOrNull }.orEmpty()
        val equippedWeapon = inv.str("equippedWeapon") ?: "training_blade"
        val armorId = avatar.str("armor") ?: "common"
        val equipmentRows = buildList {
            weapons.forEach { id -> add(EquipmentEntity(id, "weapon", id.replace('_',' ').replaceFirstChar(Char::uppercase), "unknown", true, id == equippedWeapon)) }
            add(EquipmentEntity(armorId, "armor", armorId.replace('_',' ').replaceFirstChar(Char::uppercase), "unknown", true, true))
        }

        return Mapped(
            player,
            attributeRows,
            weightRows,
            noteRows,
            chronicleRows,
            nutritionRows,
            equipmentRows,
            LegacyStateSnapshotEntity(schema = 60, rawJson = raw, sha256 = sha256(raw.toByteArray()))
        )
    }

    private fun dateToEpoch(date: String): Long = runCatching {
        LocalDate.parse(date).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
    }.getOrElse { System.currentTimeMillis() }

    fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
}
