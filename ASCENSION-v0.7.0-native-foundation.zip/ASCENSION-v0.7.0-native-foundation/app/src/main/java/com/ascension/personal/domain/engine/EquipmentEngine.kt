package com.ascension.personal.domain.engine

import com.ascension.personal.domain.model.EquipmentDefinition
import com.ascension.personal.domain.model.PlayerSnapshot

object EquipmentEngine {
    data class Eligibility(val allowed: Boolean, val reasons: List<String>)

    fun eligibility(item: EquipmentDefinition, player: PlayerSnapshot, legendaryCompleted: Set<String> = emptySet()): Eligibility {
        val r = item.requirement
        val failures = buildList {
            if (player.level < r.minLevel) add("Requires Level ${r.minLevel}")
            r.minStrength?.let { if (player.strength < it) add("Requires STR ${it.toInt()}") }
            r.minEndurance?.let { if (player.endurance < it) add("Requires END ${it.toInt()}") }
            r.minMobility?.let { if (player.mobility < it) add("Requires MOB ${it.toInt()}") }
            r.minDiscipline?.let { if (player.discipline < it) add("Requires DISC ${it.toInt()}") }
            r.minBenchBodyWeightRatio?.let { ratio ->
                val bw = player.bodyWeightLb
                val bench = player.benchEstimated1RmLb
                if (bw == null || bench == null || bw <= 0 || bench / bw < ratio) {
                    add("Requires estimated bench ≥ ${ratio}× bodyweight")
                }
            }
            r.requiresLegendaryQuest?.let { if (it !in legendaryCompleted) add("Requires Legendary Quest: $it") }
        }
        return Eligibility(failures.isEmpty(), failures)
    }
}
