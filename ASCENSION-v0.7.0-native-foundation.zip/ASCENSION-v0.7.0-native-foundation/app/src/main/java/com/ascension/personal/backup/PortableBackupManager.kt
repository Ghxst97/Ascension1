package com.ascension.personal.backup

import android.content.Context
import android.net.Uri
import com.ascension.personal.data.db.AscensionDatabase
import com.ascension.personal.data.repo.LegacyStateMapper
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class PortableBackupManager(
    private val context: Context,
    private val db: AscensionDatabase
) {
    @Serializable
    data class Manifest(
        val format: String = "ASCENSION_PORTABLE_BACKUP",
        val schema: Int = 1,
        val appVersion: String = "0.7.0-foundation",
        val createdAt: Long = System.currentTimeMillis(),
        val stateSha256: String,
        val photoCount: Int,
        val encrypted: Boolean = false
    )

    private val json = Json { prettyPrint = true }

    /**
     * Transitional v0.7 backup: stores the complete v0.6 state JSON plus every native progress photo.
     * Because the full legacy payload is preserved byte-for-byte, later native versions can migrate
     * fields that v0.7 does not yet normalize without data loss.
     */
    suspend fun write(uri: Uri, rawLegacyState: String) {
        val photos = db.ascensionDao().photos()
        val manifest = Manifest(
            stateSha256 = LegacyStateMapper.sha256(rawLegacyState.toByteArray()),
            photoCount = photos.size
        )
        context.contentResolver.openOutputStream(uri, "w")!!.use { os ->
            ZipOutputStream(os.buffered()).use { zip ->
                zip.putNextEntry(ZipEntry("manifest.json"))
                zip.write(json.encodeToString(manifest).toByteArray())
                zip.closeEntry()

                zip.putNextEntry(ZipEntry("state-v060.json"))
                zip.write(rawLegacyState.toByteArray())
                zip.closeEntry()

                zip.putNextEntry(ZipEntry("photos.json"))
                zip.write(json.encodeToString(ListSerializer(com.ascension.personal.data.db.ProgressPhotoEntity.serializer()), photos).toByteArray())
                zip.closeEntry()

                photos.forEach { photo ->
                    val file = File(context.filesDir, photo.relativePath)
                    if (file.exists()) {
                        zip.putNextEntry(ZipEntry("photos/${file.name}"))
                        file.inputStream().use { it.copyTo(zip) }
                        zip.closeEntry()
                    }
                }
            }
        }
    }

    data class Restored(val rawLegacyState: String, val restoredPhotos: Int)

    suspend fun restore(uri: Uri): Restored {
        var manifest: Manifest? = null
        var state: String? = null
        var count = 0
        var photoRows: List<com.ascension.personal.data.db.ProgressPhotoEntity> = emptyList()
        context.contentResolver.openInputStream(uri)!!.use { input ->
            ZipInputStream(input.buffered()).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    when {
                        entry.name == "manifest.json" -> manifest = json.decodeFromString(Manifest.serializer(), zip.readBytes().decodeToString())
                        entry.name == "state-v060.json" -> state = zip.readBytes().decodeToString()
                        entry.name == "photos.json" -> photoRows = json.decodeFromString(ListSerializer(com.ascension.personal.data.db.ProgressPhotoEntity.serializer()), zip.readBytes().decodeToString())
                        entry.name.startsWith("photos/") && !entry.isDirectory -> {
                            val dir = File(context.filesDir, "progress_photos").apply { mkdirs() }
                            val safeName = File(entry.name).name
                            File(dir, safeName).outputStream().use { zip.copyTo(it) }
                            count++
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
        }
        val m = requireNotNull(manifest) { "Missing ASCENSION manifest" }
        require(m.format == "ASCENSION_PORTABLE_BACKUP") { "Wrong backup format" }
        val raw = requireNotNull(state) { "Missing player state" }
        require(LegacyStateMapper.sha256(raw.toByteArray()) == m.stateSha256) { "Backup integrity check failed" }
        photoRows.forEach { row ->
            val f = File(context.filesDir, row.relativePath)
            if (f.exists() && LegacyStateMapper.sha256(f.readBytes()) == row.sha256) db.ascensionDao().upsertPhoto(row)
        }
        return Restored(raw, count)
    }
}
