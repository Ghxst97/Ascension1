package com.ascension.personal.domain.engine

import com.ascension.personal.domain.model.DungeonDefinition
import com.ascension.personal.domain.model.ExpeditionResult
import java.security.MessageDigest
import kotlin.math.max
import kotlin.math.min

object DungeonEngine {
    fun resolve(
        dungeon: DungeonDefinition,
        playerLevel: Int,
        playerPower: Int,
        seed: String
    ): ExpeditionResult {
        val qualified = playerLevel >= dungeon.minLevel
        val ratio = playerPower.toDouble() / dungeon.recommendedPower.coerceAtLeast(1)
        val chance = max(0.05, min(0.96, 0.50 + (ratio - 1.0) * 0.82 - if (dungeon.boss) 0.08 else 0.0))
        val roll = deterministicRoll(seed)
        val won = qualified && roll < chance
        val baseXp = when (dungeon.grade) {
            "common" -> 140
            "rare" -> 260
            "epic" -> 520
            "legendary" -> 950
            "mythic" -> 1600
            else -> 140
        }
        val xp = if (won) baseXp + if (dungeon.boss) 220 else 0 else 0
        val log = buildList {
            add("ENTER // ${dungeon.name}")
            add("Combat Power $playerPower vs ${dungeon.recommendedPower} recommended")
            add(if (dungeon.boss) "Boss presence confirmed." else "Autonomous expedition route engaged.")
            if (won) add("CLEAR // +$xp XP")
            else add(if (qualified) "DEFEAT // Expedition withdrew safely." else "LOCKOUT // Requires Level ${dungeon.minLevel}.")
        }
        return ExpeditionResult(won, chance, playerPower, dungeon.recommendedPower, xp, dungeon.grade, log)
    }

    private fun deterministicRoll(seed: String): Double {
        val digest = MessageDigest.getInstance("SHA-256").digest(seed.toByteArray())
        val n = ((digest[0].toInt() and 0xff) shl 24) or
            ((digest[1].toInt() and 0xff) shl 16) or
            ((digest[2].toInt() and 0xff) shl 8) or
            (digest[3].toInt() and 0xff)
        val unsigned = n.toLong() and 0xffffffffL
        return unsigned.toDouble() / 0xffffffffL.toDouble()
    }
}
