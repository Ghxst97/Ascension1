package com.ascension.personal.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface PlayerDao {
    @Query("SELECT * FROM player WHERE id = 1")
    fun observe(): Flow<PlayerEntity?>

    @Query("SELECT * FROM player WHERE id = 1")
    suspend fun get(): PlayerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(player: PlayerEntity)
}

@Dao
interface AscensionDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAttributes(items: List<AttributeEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertWeights(items: List<WeightEntryEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertNotes(items: List<NoteEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertChronicle(items: List<ChronicleEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertPhoto(item: ProgressPhotoEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertDungeon(item: DungeonRunEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertEquipment(items: List<EquipmentEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertQuestEvents(items: List<QuestEventEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertNutrition(items: List<NutritionDayEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertLegacy(item: LegacyStateSnapshotEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertMeta(item: AppMetaEntity)

    @Query("SELECT * FROM attributes ORDER BY key") suspend fun attributes(): List<AttributeEntity>
    @Query("SELECT * FROM weights ORDER BY recordedAt") suspend fun weights(): List<WeightEntryEntity>
    @Query("SELECT * FROM notes ORDER BY date") suspend fun notes(): List<NoteEntity>
    @Query("SELECT * FROM chronicle ORDER BY occurredAt") suspend fun chronicle(): List<ChronicleEntity>
    @Query("SELECT * FROM progress_photos ORDER BY createdAt") suspend fun photos(): List<ProgressPhotoEntity>
    @Query("SELECT * FROM dungeon_runs ORDER BY startedAt") suspend fun dungeons(): List<DungeonRunEntity>
    @Query("SELECT * FROM equipment ORDER BY kind, grade, name") suspend fun equipment(): List<EquipmentEntity>
    @Query("SELECT * FROM quest_events ORDER BY createdAt") suspend fun questEvents(): List<QuestEventEntity>
    @Query("SELECT * FROM nutrition_days ORDER BY date") suspend fun nutrition(): List<NutritionDayEntity>
    @Query("SELECT * FROM legacy_snapshots WHERE id=1") suspend fun legacy(): LegacyStateSnapshotEntity?
    @Query("SELECT value FROM app_meta WHERE key=:key") suspend fun meta(key: String): String?

    @Query("DELETE FROM progress_photos") suspend fun clearPhotos()
    @Query("DELETE FROM dungeon_runs") suspend fun clearDungeons()
}
