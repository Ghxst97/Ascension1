package com.ascension.personal.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build

object NotificationChannels {
    const val EXPEDITIONS = "expeditions"
    fun ensureCreated(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = context.getSystemService(NotificationManager::class.java)
            mgr.createNotificationChannel(NotificationChannel(EXPEDITIONS, "Dungeon expeditions", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "ASCENSION world-event and expedition-return alerts"
            })
        }
    }
}
