package com.ascension.personal.data.repo

import androidx.room.withTransaction
import com.ascension.personal.data.db.*

class AscensionRepository(private val db: AscensionDatabase) {
    suspend fun importLegacyJson(raw: String): Boolean {
        if (raw.isBlank()) return false
        val dao = db.ascensionDao()
        val existingHash = dao.legacy()?.sha256
        val mapped = LegacyStateMapper.map(raw)
        if (existingHash == mapped.snapshot.sha256) return false

        db.withTransaction {
            db.playerDao().upsert(mapped.player)
            dao.upsertAttributes(mapped.attributes)
            dao.upsertWeights(mapped.weights)
            dao.upsertNotes(mapped.notes)
            dao.upsertChronicle(mapped.chronicle)
            dao.upsertNutrition(mapped.nutrition)
            dao.upsertEquipment(mapped.equipment)
            dao.upsertLegacy(mapped.snapshot)
            dao.upsertMeta(AppMetaEntity("legacy_import_complete", "true"))
            dao.upsertMeta(AppMetaEntity("legacy_schema", "60"))
        }
        return true
    }

    suspend fun persistLegacySnapshot(raw: String) {
        if (raw.isBlank()) return
        val hash = LegacyStateMapper.sha256(raw.toByteArray())
        db.ascensionDao().upsertLegacy(LegacyStateSnapshotEntity(schema = 60, rawJson = raw, sha256 = hash))
    }

    suspend fun savePhoto(photo: ProgressPhotoEntity) = db.ascensionDao().upsertPhoto(photo)
    suspend fun player(): PlayerEntity? = db.playerDao().get()
}
