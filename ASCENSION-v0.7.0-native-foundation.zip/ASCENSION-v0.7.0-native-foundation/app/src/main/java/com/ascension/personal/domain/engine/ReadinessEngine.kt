package com.ascension.personal.domain.engine

object ReadinessEngine {
    enum class Mode { NORMAL, CAUTION, RECOVERY }
    data class Result(val mode: Mode, val score: Int, val guidance: String)

    fun assess(sleepHours: Double, soreness: Int, sharpPain: Boolean): Result {
        if (sharpPain) return Result(Mode.RECOVERY, 20, "Replace heavy loading with easy walking and pain-free mobility.")
        val sleepPenalty = when {
            sleepHours < 5.0 -> 45
            sleepHours < 6.0 -> 30
            sleepHours < 6.5 -> 20
            sleepHours < 7.0 -> 10
            else -> 0
        }
        val sorenessPenalty = when {
            soreness >= 9 -> 45
            soreness == 8 -> 35
            soreness == 7 -> 25
            soreness == 6 -> 15
            soreness == 5 -> 8
            else -> 0
        }
        val score = (100 - sleepPenalty - sorenessPenalty).coerceAtLeast(10)
        return when {
            sleepHours < 5.0 || soreness >= 8 || score < 50 -> Result(Mode.RECOVERY, score, "Recovery Override")
            sleepHours < 6.75 || soreness >= 6 || score < 80 -> Result(Mode.CAUTION, score, "Reduce load/volume; no PR attempts.")
            else -> Result(Mode.NORMAL, score, "Run the planned session.")
        }
    }
}
