package com.ascension.personal.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        PlayerEntity::class,
        AttributeEntity::class,
        WeightEntryEntity::class,
        NoteEntity::class,
        ChronicleEntity::class,
        ProgressPhotoEntity::class,
        DungeonRunEntity::class,
        EquipmentEntity::class,
        QuestEventEntity::class,
        NutritionDayEntity::class,
        LegacyStateSnapshotEntity::class,
        AppMetaEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class AscensionDatabase : RoomDatabase() {
    abstract fun playerDao(): PlayerDao
    abstract fun ascensionDao(): AscensionDao

    companion object {
        fun create(context: Context): AscensionDatabase = Room.databaseBuilder(
            context,
            AscensionDatabase::class.java,
            "ascension.db"
        )
            // Never use destructive migrations in production. Add explicit migrations as schema evolves.
            .build()
    }
}
