package com.ascension.personal.domain.model

import kotlinx.serialization.Serializable

@Serializable
data class PlayerSnapshot(
    val name: String,
    val level: Int,
    val rank: String,
    val xp: Int,
    val strength: Double,
    val endurance: Double,
    val mobility: Double,
    val recovery: Double,
    val discipline: Double,
    val physique: Double,
    val connection: Double,
    val experience: Double,
    val benchEstimated1RmLb: Double? = null,
    val bodyWeightLb: Double? = null,
    val fiveKSeconds: Int? = null
)

@Serializable
data class EquipmentRequirement(
    val minLevel: Int = 1,
    val minStrength: Double? = null,
    val minEndurance: Double? = null,
    val minMobility: Double? = null,
    val minDiscipline: Double? = null,
    val minBenchBodyWeightRatio: Double? = null,
    val requiresLegendaryQuest: String? = null
)

@Serializable
data class EquipmentDefinition(
    val id: String,
    val name: String,
    val kind: String,
    val grade: String,
    val modifierPercent: Double,
    val requirement: EquipmentRequirement
)

@Serializable
data class DungeonDefinition(
    val id: String,
    val name: String,
    val grade: String,
    val minLevel: Int,
    val recommendedPower: Int,
    val durationMinutes: Int,
    val boss: Boolean = false
)

@Serializable
data class ExpeditionResult(
    val won: Boolean,
    val clearChance: Double,
    val playerPower: Int,
    val recommendedPower: Int,
    val xp: Int,
    val grade: String,
    val log: List<String>
)
