package com.ascension.personal

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.ascension.personal.backup.PortableBackupManager
import com.ascension.personal.data.repo.AscensionRepository
import com.ascension.personal.migration.AscensionNativeBridge
import com.ascension.personal.photos.ProgressPhotoRepository
import com.ascension.personal.ui.LegacyAscensionSurface
import com.ascension.personal.ui.theme.AscensionTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.time.LocalDate

class MainActivity : ComponentActivity(), AscensionNativeBridge.Host {
    private lateinit var repository: AscensionRepository
    private lateinit var backupManager: PortableBackupManager
    private lateinit var photoRepository: ProgressPhotoRepository
    private lateinit var bridge: AscensionNativeBridge
    private var webView: WebView? = null
    private var pendingBackupState: String? = null
    private var pendingPhoto: ProgressPhotoRepository.PendingCapture? = null

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val createBackup = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        val raw = pendingBackupState
        pendingBackupState = null
        if (uri != null && raw != null) {
            lifecycleScope.launch(Dispatchers.IO) {
                runCatching { backupManager.write(uri, raw) }
                withContext(Dispatchers.Main) { toastWeb("PLAYER VAULT SAVED") }
            }
        }
    }

    private val openBackup = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        lifecycleScope.launch(Dispatchers.IO) {
            val result = runCatching { backupManager.restore(uri) }
            result.onSuccess { restored ->
                repository.importLegacyJson(restored.rawLegacyState)
                withContext(Dispatchers.Main) {
                    val quoted = JSONObject.quote(restored.rawLegacyState)
                    webView?.evaluateJavascript(
                        "localStorage.setItem('ascension.v030.state',$quoted);location.reload();",
                        null
                    )
                }
            }.onFailure {
                withContext(Dispatchers.Main) { toastWeb("BACKUP RESTORE FAILED") }
            }
        }
    }

    private val takePhoto = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val capture = pendingPhoto
        pendingPhoto = null
        if (!ok || capture == null) {
            capture?.file?.delete()
            return@registerForActivityResult
        }
        lifecycleScope.launch(Dispatchers.IO) {
            val entity = photoRepository.toEntity(capture)
            repository.savePhoto(entity)
            withContext(Dispatchers.Main) {
                webView?.evaluateJavascript(
                    "window.A&&window.A.nativePhotoSaved&&window.A.nativePhotoSaved(${JSONObject.quote(capture.date)},${JSONObject.quote(capture.slot)});",
                    null
                )
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as AscensionApplication
        repository = AscensionRepository(app.database)
        backupManager = PortableBackupManager(this, app.database)
        photoRepository = ProgressPhotoRepository(this)
        bridge = AscensionNativeBridge(this, repository, lifecycleScope)

        setContent {
            AscensionTheme {
                LegacyAscensionSurface(bridge) { webView = it }
            }
        }
    }

    override fun requestBackup(rawState: String) {
        runOnUiThread {
            pendingBackupState = rawState
            createBackup.launch("ASCENSION-${LocalDate.now()}.ascension")
        }
    }

    override fun requestRestore() {
        runOnUiThread { openBackup.launch(arrayOf("application/octet-stream", "application/zip", "*/*")) }
    }

    override fun requestProgressPhoto(date: String, slot: String) {
        runOnUiThread {
            val capture = photoRepository.createCapture(date, slot)
            pendingPhoto = capture
            takePhoto.launch(capture.uri)
        }
    }

    override fun ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            runOnUiThread { notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS) }
        }
    }

    override fun appContext() = applicationContext

    private fun toastWeb(message: String) {
        webView?.evaluateJavascript("if(window.toast)toast(${JSONObject.quote(message)});", null)
    }
}
