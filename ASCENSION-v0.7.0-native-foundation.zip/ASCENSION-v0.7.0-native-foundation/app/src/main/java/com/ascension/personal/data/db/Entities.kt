package com.ascension.personal.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Entity(tableName = "player")
data class PlayerEntity(
    @PrimaryKey val id: Int = 1,
    val name: String = "",
    val age: Int? = null,
    val heightInches: Int? = null,
    val weightLb: Double? = null,
    val sex: String = "male",
    val goal: String = "muscle",
    val experience: String = "beginner",
    val journeyStartedAt: Long? = null,
    val xp: Int = 0,
    val streak: Int = 0,
    val bestStreak: Int = 0,
    val revivalStones: Int = 2,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "attributes")
data class AttributeEntity(
    @PrimaryKey val key: String,
    val value: Double,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "weights", indices = [Index(value = ["recordedAt"])])
data class WeightEntryEntity(
    @PrimaryKey val id: String,
    val recordedAt: Long,
    val weightLb: Double,
    val source: String = "manual"
)

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey val date: String,
    val text: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "chronicle", indices = [Index(value = ["occurredAt"])])
data class ChronicleEntity(
    @PrimaryKey val id: String,
    val occurredAt: Long,
    val grade: String,
    val title: String,
    val detail: String,
    val payloadJson: String? = null
)

@Serializable
@Entity(tableName = "progress_photos", indices = [Index(value = ["date"])])
data class ProgressPhotoEntity(
    @PrimaryKey val id: String,
    val date: String,
    val slot: String,
    val relativePath: String,
    val sha256: String,
    val width: Int? = null,
    val height: Int? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "dungeon_runs", indices = [Index(value = ["endsAt"])])
data class DungeonRunEntity(
    @PrimaryKey val id: String,
    val templateId: String,
    val grade: String,
    val name: String,
    val boss: Boolean,
    val startedAt: Long,
    val endsAt: Long,
    val powerAtStart: Int,
    val result: String = "ACTIVE",
    val rewardJson: String? = null
)

@Entity(tableName = "equipment")
data class EquipmentEntity(
    @PrimaryKey val id: String,
    val kind: String,
    val name: String,
    val grade: String,
    val unlocked: Boolean,
    val equipped: Boolean,
    val requirementJson: String? = null,
    val modifierPercent: Double = 0.0,
    val acquiredAt: Long? = null
)

@Entity(tableName = "quest_events", indices = [Index(value = ["date"]), Index(value = ["type"])])
data class QuestEventEntity(
    @PrimaryKey val id: String,
    val date: String,
    val type: String,
    val questId: String,
    val title: String,
    val xp: Int,
    val metadataJson: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "nutrition_days")
data class NutritionDayEntity(
    @PrimaryKey val date: String,
    val calories: Int,
    val proteinG: Int,
    val carbsG: Int,
    val fatG: Int,
    val meals: Int
)

@Entity(tableName = "legacy_snapshots")
data class LegacyStateSnapshotEntity(
    @PrimaryKey val id: Int = 1,
    val schema: Int,
    val rawJson: String,
    val sha256: String,
    val importedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "app_meta")
data class AppMetaEntity(
    @PrimaryKey val key: String,
    val value: String
)
