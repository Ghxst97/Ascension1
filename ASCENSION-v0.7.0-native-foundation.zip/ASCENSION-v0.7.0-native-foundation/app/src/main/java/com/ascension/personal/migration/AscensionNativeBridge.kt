package com.ascension.personal.migration

import android.webkit.JavascriptInterface
import com.ascension.personal.data.repo.AscensionRepository
import com.ascension.personal.notifications.ExpeditionScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.security.MessageDigest

class AscensionNativeBridge(
    private val host: Host,
    private val repository: AscensionRepository,
    private val scope: CoroutineScope
) {
    interface Host {
        fun requestBackup(rawState: String)
        fun requestRestore()
        fun requestProgressPhoto(date: String, slot: String)
        fun ensureNotificationPermission()
        fun appContext(): android.content.Context
    }

    private var persistJob: Job? = null
    private var lastHash: String? = null

    @JavascriptInterface
    fun platform(): String = "android-native-foundation-0.7"

    @JavascriptInterface
    fun persistState(rawState: String) {
        val hash = sha256(rawState)
        if (hash == lastHash) return
        lastHash = hash
        persistJob?.cancel()
        persistJob = scope.launch(Dispatchers.IO) {
            delay(250)
            runCatching { repository.importLegacyJson(rawState) }
        }
    }

    @JavascriptInterface
    fun requestBackup(rawState: String) = host.requestBackup(rawState)

    @JavascriptInterface
    fun requestRestore() = host.requestRestore()

    @JavascriptInterface
    fun captureProgressPhoto(date: String, slot: String) = host.requestProgressPhoto(date, slot)

    @JavascriptInterface
    fun scheduleExpedition(id: String, name: String, finishAtMs: Long) {
        host.ensureNotificationPermission()
        ExpeditionScheduler.schedule(host.appContext(), id, name, finishAtMs)
    }

    @JavascriptInterface
    fun cancelExpedition(id: String) {
        ExpeditionScheduler.cancel(host.appContext(), id)
    }

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray())
        .joinToString("") { "%02x".format(it) }
}
