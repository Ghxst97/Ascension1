package com.ascension.personal.photos

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import com.ascension.personal.data.db.ProgressPhotoEntity
import com.ascension.personal.data.repo.LegacyStateMapper
import java.io.File
import java.time.LocalDate
import java.util.UUID

class ProgressPhotoRepository(private val context: Context) {
    data class PendingCapture(val file: File, val uri: Uri, val date: String, val slot: String)

    fun createCapture(date: String = LocalDate.now().toString(), slot: String = "front"): PendingCapture {
        val dir = File(context.filesDir, "progress_photos").apply { mkdirs() }
        val file = File(dir, "${date}_${slot}_${UUID.randomUUID()}.jpg")
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", file)
        return PendingCapture(file, uri, date, slot)
    }

    fun toEntity(capture: PendingCapture): ProgressPhotoEntity {
        val bytes = capture.file.readBytes()
        return ProgressPhotoEntity(
            id = capture.file.nameWithoutExtension,
            date = capture.date,
            slot = capture.slot,
            relativePath = "progress_photos/${capture.file.name}",
            sha256 = LegacyStateMapper.sha256(bytes)
        )
    }
}
