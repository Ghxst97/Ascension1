package com.ascension.personal.notifications

import android.content.Context
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

object ExpeditionScheduler {
    fun schedule(context: Context, id: String, name: String, finishAtMs: Long) {
        val delay = (finishAtMs - System.currentTimeMillis()).coerceAtLeast(1_000L)
        val work = OneTimeWorkRequestBuilder<ExpeditionWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(Data.Builder()
                .putString("expeditionId", id)
                .putString("title", "EXPEDITION COMPLETE")
                .putString("body", "$name — your Player has returned.")
                .build())
            .addTag("expedition:$id")
            .build()
        WorkManager.getInstance(context).enqueue(work)
    }

    fun cancel(context: Context, id: String) {
        WorkManager.getInstance(context).cancelAllWorkByTag("expedition:$id")
    }
}
