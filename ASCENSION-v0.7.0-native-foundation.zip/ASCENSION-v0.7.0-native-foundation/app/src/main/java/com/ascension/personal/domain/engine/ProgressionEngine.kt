package com.ascension.personal.domain.engine

import com.ascension.personal.domain.model.PlayerSnapshot
import kotlin.math.roundToInt

object ProgressionEngine {
    fun levelForXp(xp: Int): Int = xp.coerceAtLeast(0) / 500 + 1

    fun rankForLevel(level: Int): String = when {
        level >= 60 -> "S"
        level >= 45 -> "A"
        level >= 30 -> "B"
        level >= 20 -> "C"
        level >= 10 -> "D"
        else -> "E"
    }

    /**
     * Game score only. It is not a medical, psychological, or scientific fitness score.
     * Real-life attributes dominate; gear is applied separately and capped.
     */
    fun baseCombatPower(player: PlayerSnapshot): Int {
        val weighted =
            player.strength * 1.35 +
            player.endurance * 1.10 +
            player.recovery * 0.95 +
            player.discipline * 1.10 +
            player.mobility * 0.80 +
            player.physique * 0.90 +
            player.connection * 0.25 +
            player.experience * 0.40
        val levelPower = player.level * 58.0
        val performance = (player.benchEstimated1RmLb ?: 0.0) * 1.6
        return (weighted * 12.0 + levelPower + performance).roundToInt().coerceAtLeast(100)
    }

    fun withGear(basePower: Int, equipmentModifiersPercent: List<Double>): Int {
        val modifier = equipmentModifiersPercent.sum().coerceIn(0.0, 8.0)
        return (basePower * (1.0 + modifier / 100.0)).roundToInt()
    }
}
