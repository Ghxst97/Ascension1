-keepclassmembers class ** {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes *Annotation*
