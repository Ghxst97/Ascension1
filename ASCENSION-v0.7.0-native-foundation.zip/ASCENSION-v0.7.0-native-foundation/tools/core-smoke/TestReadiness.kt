import com.ascension.personal.domain.engine.ReadinessEngine
fun main() {
    check(ReadinessEngine.assess(7.5, 3, false).mode == ReadinessEngine.Mode.NORMAL)
    check(ReadinessEngine.assess(5.5, 3, false).mode == ReadinessEngine.Mode.CAUTION)
    check(ReadinessEngine.assess(4.5, 3, false).mode == ReadinessEngine.Mode.RECOVERY)
    check(ReadinessEngine.assess(8.0, 2, true).mode == ReadinessEngine.Mode.RECOVERY)
    println("readiness smoke: OK")
}
