#!/usr/bin/env bash
set -euo pipefail
command -v gradle >/dev/null || { echo "Install Gradle 8.13 first."; exit 1; }
gradle wrapper --gradle-version 8.13
