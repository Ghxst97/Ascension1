# Signing and in-place updates

Android treats an app's signing key as part of its identity.

ASCENSION v0.3+ uses an existing signing identity. To update the currently installed app without uninstalling it, the new native release must use:

- applicationId: `com.ascension.personal`
- a versionCode higher than the installed APK
- the **same existing signing key**

The source project intentionally does not contain the keystore or its password.

## GitHub Actions secrets

The included workflow understands these secrets:

- `ASCENSION_KEYSTORE_B64` — existing `.jks` file encoded as base64
- `ASCENSION_KEYSTORE_PASSWORD`
- `ASCENSION_KEY_ALIAS` — normally `ascension`
- `ASCENSION_KEY_PASSWORD`

The workflow reconstructs the keystore inside the temporary runner and deletes it with the runner after the job.

Never commit:

- `.jks` files
- passwords
- `secrets.properties`

## Debug safety

Debug uses an `.dev` application ID suffix. That is intentional. It allows architectural testing without touching the real Player profile.
