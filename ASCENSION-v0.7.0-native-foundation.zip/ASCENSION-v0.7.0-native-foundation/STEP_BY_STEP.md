# Step-by-step: getting ASCENSION onto the native foundation for $0

## 1. Do not uninstall v0.6
Your existing Android data is easiest to preserve through an in-place signed update.

Before touching anything:
- export the current Player Capsule/backup
- keep the v0.6 APK

## 2. Put this source tree in `Ghxst97/Ascension1`
The repository, not an APK, should become the source of truth.

Once ChatGPT's GitHub connection can see the repo, this can be done directly. Otherwise commit the contents of this source ZIP manually.

## 3. Build the debug version first
Run the included GitHub Action. It creates a separate `com.ascension.personal.dev` app.

Test:
- app starts
- current UI works
- Fold/folded orientation works
- camera opens from Daily Evidence
- `.ascension` backup chooser opens
- dungeon notification can fire

This test version cannot overwrite the real ASCENSION app.

## 4. Configure release signing
Add the existing ASCENSION v0.3+ keystore as GitHub Actions secrets. Do not make a new signing key.

Required secrets are documented in `SIGNING_AND_UPDATES.md`.

## 5. Build the signed release
Run the Action again. With signing secrets configured it will also create a release APK using:
- package `com.ascension.personal`
- versionCode 700

## 6. Test the real migration
With v0.6 still installed, install the signed v0.7 release APK over it.

Do not clear app data.

Open ASCENSION and verify the old Player is intact. The legacy page dual-writes its entire state to Room and preserves the raw source JSON with a checksum.

## 7. Verify the safety-critical native features
### Player Vault
Export an `.ascension` backup to a second location and verify it can restore into the debug app.

### Daily Evidence
Take one progress photo and confirm it is private to ASCENSION rather than appearing as an ordinary public gallery file.

### Expedition alert
Deploy a short test dungeon, close the app, and verify the completion notification.

## 8. Port the app gradually
Do not rewrite everything simultaneously.

Order:
1. Player/Profile data becomes Room-authoritative
2. Chronicle/event ledger
3. workouts + exercise sets
4. quests + Legendary/Life quests
5. nutrition
6. World/game data
7. System screen in Compose
8. Train
9. Fuel
10. Journey
11. Player

## 9. Remove the WebView only after parity
The v0.6 HTML stays as a migration safety net until all five native screens and every data domain have passed migration/backup tests.

## 10. Stay at $0
Do not add a backend unless a future feature truly requires it. Core ASCENSION should remain offline-first.

Use:
- Room/SQLite
- Compose
- WorkManager
- Android document picker
- app-private files
- GitHub Actions within the account's free allowance

Treat AI features and automatic multi-device sync as optional future providers, never dependencies of the core app.
