# ASCENSION v0.2

ASCENSION is a private, offline-first Android RPG-style self-improvement app built for one user. It stores everything locally on-device and intentionally has no account system, backend, analytics, ads, subscriptions, or Internet permission.

## What v0.2 adds

### 7-day Ascension program

- **Monday — Upper Strength**
  - Bench press 4×3–5
  - Weighted pull-up/chin-up 4×4–6
  - Overhead press 3×4–6
  - Chest-supported row 3×5–8
  - Incline dumbbell press 2×8–10
  - Lateral raise 3×12–20
- **Tuesday — Lower Strength**
  - Back squat 4×3–5
  - Romanian deadlift 3×5–8
  - Bulgarian split squat 3×6–10/leg
  - Leg curl 3×8–12
  - Standing calf raise 4×8–15
  - Ab wheel 3×8–15
- **Wednesday — Recovery / Mobility**
  - 30–40 min Zone 2 cardio / brisk walk
  - Hip, thoracic, shoulder, and ankle mobility
  - Midweek 10-minute mental reset quest
- **Thursday — Back / Delts / Traps**
- **Friday — Chest / Arms**
- **Saturday — Legs / Deadlift**
- **Sunday — Cardio / Weekly Reset**
  - 35–45 min easy cardio
  - Full-body mobility
  - Weekly review + next-week planning quest

The strength/hypertrophy program uses double progression and keeps most hard work around 1–2 RIR instead of requiring failure.

### Readiness engine

Every day starts with a check-in:

- Sleep hours
- Whole-body soreness (0–10)
- Sharp / joint / injury-like pain toggle

The app then assigns one of three modes:

- **Combat Ready:** normal session
- **Caution Mode:** ~90% normal load, one fewer set on most lifting exercises, ~3 RIR, no PR chasing
- **Recovery Override:** heavy loading is replaced with easy walking + pain-free mobility

Recovery decisions still earn training quest credit. The app does not reward grinding through injury-like pain.

### Revival Stones

- 2 Revival Stones per month by default
- One Stone protects one missed day from breaking the current streak
- Stones do not award free XP
- No punishment workouts or food restriction are ever assigned for missed quests

### Long-form Challenge Quests

The new Quests tab includes a curated starting library of 7- or 14-day reading challenges:

- Atomic Habits
- Man's Search for Meaning
- How to Win Friends and Influence People
- Meditations
- The Psychology of Money
- Deep Work
- The Scout Mindset
- Make It Stick

Only one Challenge Quest can be active at a time. Progress can be logged once per calendar day. Each reading session awards +40 XP and finishing the challenge awards a larger completion bonus.

### Baseline nutrition targets

- 2,700 kcal/day
- 150 g protein/day
- 365 g carbs/day
- 70 g fat/day
- 8,000 steps/day
- 7+ hours sleep bonus

These are starting targets, not permanent prescriptions. Future versions should use bodyweight trend to recommend calorie changes.

## Tech

- Kotlin
- Jetpack Compose
- DataStore Preferences + kotlinx.serialization
- Android min SDK 26
- Android target / compile SDK 35
- Local-only storage
- Responsive phone / foldable layout

## Build without a PC

The repo includes `.github/workflows/build-apk.yml`. Upload the project to GitHub and run the **Build Ascension APK** workflow. GitHub installs JDK 17, Android SDK 35, and Gradle 8.9, then runs `gradle assembleDebug` and uploads the resulting APK as an Actions artifact.

See `PHONE_BUILD.md` for the phone/iPad workflow.

## Safety

ASCENSION is a training and habit-tracking tool, not a diagnostic or medical device. Sharp, severe, worsening, or persistent pain should not be treated as a gamification problem. Seek appropriate medical care when needed.
