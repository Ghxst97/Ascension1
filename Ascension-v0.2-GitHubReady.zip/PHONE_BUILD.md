# Build ASCENSION v0.2 from a phone or iPad

The ZIP contains source code. Android cannot install it until it is compiled into an APK.

## Easiest route: GitHub Actions

1. Extract the ASCENSION source ZIP.
2. Upload the **contents of the `Ascension-v0.2` folder** to the root of your GitHub `Ascension` repository. The repo root should contain `app`, `.github`, `build.gradle.kts`, and `settings.gradle.kts`.
3. Open the repo on GitHub and tap **Actions**.
4. Open **Build Ascension APK**.
5. Tap **Run workflow** if a run did not start automatically after upload.
6. Wait for the build to finish.
7. Open the successful workflow run and download the artifact named **Ascension-v0.2-debug-apk**.
8. Extract that downloaded artifact ZIP. Inside is `app-debug.apk`.
9. Move `app-debug.apk` to the Android phone and open it.
10. If Android asks, allow your browser/files app to install unknown apps, then install ASCENSION.

The app is local-only and does not require an account after installation.
