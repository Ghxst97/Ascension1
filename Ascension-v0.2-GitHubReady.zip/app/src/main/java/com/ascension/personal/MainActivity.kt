package com.ascension.personal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.ascension.personal.data.AscensionRepository
import com.ascension.personal.ui.AscensionApp
import com.ascension.personal.ui.theme.AscensionTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repository = AscensionRepository(applicationContext)
        setContent {
            AscensionTheme {
                AscensionApp(repository)
            }
        }
    }
}
