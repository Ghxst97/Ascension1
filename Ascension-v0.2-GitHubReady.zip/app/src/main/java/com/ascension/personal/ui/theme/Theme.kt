package com.ascension.personal.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AscensionColors = darkColorScheme(
    primary = Color(0xFF6EA8FF),
    onPrimary = Color(0xFF07101F),
    primaryContainer = Color(0xFF132844),
    onPrimaryContainer = Color(0xFFD6E5FF),
    secondary = Color(0xFF9CAEFF),
    tertiary = Color(0xFF72E6D1),
    background = Color(0xFF070B14),
    onBackground = Color(0xFFEAF0FF),
    surface = Color(0xFF0D1320),
    onSurface = Color(0xFFEAF0FF),
    surfaceVariant = Color(0xFF151D2C),
    onSurfaceVariant = Color(0xFFB8C3D9),
    error = Color(0xFFFF8D91),
    outline = Color(0xFF536079)
)

@Composable
fun AscensionTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AscensionColors,
        typography = MaterialTheme.typography,
        content = content
    )
}
