package com.ascension.personal.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.ascension.personal.model.ActiveChallenge
import com.ascension.personal.model.AppState
import com.ascension.personal.model.ChallengeDefinition
import com.ascension.personal.model.ChallengeLibrary
import com.ascension.personal.model.DailyLog
import com.ascension.personal.model.QuestDefinition
import com.ascension.personal.model.Readiness
import com.ascension.personal.model.ReadinessMode
import com.ascension.personal.model.WorkoutPlan
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import kotlin.math.max

private val Context.ascensionDataStore by preferencesDataStore(name = "ascension_state")

class AscensionRepository(private val context: Context) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val stateKey = stringPreferencesKey("state_json")
    private val _state = MutableStateFlow(AppState())
    val state: StateFlow<AppState> = _state

    init {
        scope.launch {
            val stored = context.ascensionDataStore.data.first()[stateKey]
            val decoded = runCatching {
                if (stored.isNullOrBlank()) AppState() else json.decodeFromString<AppState>(stored)
            }.getOrElse { AppState() }
            val normalized = normalizeMonth(decoded)
            _state.value = normalized
            persist(normalized)
        }
    }

    fun readiness(date: LocalDate, state: AppState = _state.value): Readiness {
        val log = state.logs[date.toString()] ?: DailyLog()
        if (!log.checkInSaved) {
            return Readiness(
                ReadinessMode.UNASSESSED,
                0,
                "CHECK-IN REQUIRED",
                "Log sleep, soreness and pain status before the System sets today's training stress."
            )
        }

        if (log.sharpPain) {
            return Readiness(
                ReadinessMode.RECOVERY,
                20,
                "RECOVERY OVERRIDE",
                "Sharp, joint, or injury-like pain overrides the lifting plan. Use easy walking and pain-free mobility instead; worsening or persistent pain deserves medical evaluation."
            )
        }

        val sleepPenalty = when {
            log.sleepHours < 5f -> 45
            log.sleepHours < 6f -> 30
            log.sleepHours < 6.5f -> 20
            log.sleepHours < 7f -> 10
            else -> 0
        }
        val sorenessPenalty = when {
            log.soreness >= 9 -> 45
            log.soreness == 8 -> 35
            log.soreness == 7 -> 25
            log.soreness == 6 -> 15
            log.soreness == 5 -> 8
            else -> 0
        }
        val score = max(10, 100 - sleepPenalty - sorenessPenalty)

        if (log.sleepHours < 5f || log.soreness >= 8 || score < 50) {
            return Readiness(
                ReadinessMode.RECOVERY,
                score,
                "RECOVERY OVERRIDE",
                "Recovery is the productive choice today. Skip heavy loading, walk easily, complete mobility, eat normally, and return when readiness improves."
            )
        }

        if (log.sleepHours < 6.75f || log.soreness >= 6 || score < 80) {
            return Readiness(
                ReadinessMode.CAUTION,
                score,
                "CAUTION MODE",
                "Use about 90% of normal load, remove one set from most exercises, keep roughly 3 RIR, and do not chase PRs."
            )
        }

        return Readiness(
            ReadinessMode.NORMAL,
            score,
            "COMBAT READY",
            "Run the planned session. Keep most compound work around 1–2 RIR and earn progression with clean reps."
        )
    }

    fun questsFor(date: LocalDate, state: AppState = _state.value): List<QuestDefinition> {
        val targets = state.settings.nutrition
        val workout = WorkoutPlan.forDate(date)
        val ready = readiness(date, state)
        val trainingTitle = when {
            workout.recoveryDay -> "Complete ${workout.title}"
            ready.mode == ReadinessMode.RECOVERY -> "Complete Recovery Override"
            else -> "Complete ${workout.title}"
        }
        val trainingSubtitle = when {
            workout.recoveryDay -> workout.focus
            ready.mode == ReadinessMode.RECOVERY -> "Heavy training is replaced today; protecting tomorrow's performance still earns full credit."
            ready.mode == ReadinessMode.CAUTION -> "Adjusted volume and load based on today's readiness check."
            else -> "Follow today's programmed session and log completion."
        }

        val quests = mutableListOf(
            QuestDefinition("checkin", "Submit Readiness Check", "Sleep + soreness + pain status", 40),
            QuestDefinition("training", trainingTitle, trainingSubtitle, 120, manual = true)
        )

        if (date.dayOfWeek == DayOfWeek.WEDNESDAY) {
            quests += QuestDefinition(
                "cardio",
                "30–40 Minutes Zone 2",
                "Brisk walk, bike, incline treadmill, or similar easy aerobic work",
                80,
                manual = true
            )
            quests += QuestDefinition(
                "mindset",
                "10-Minute Midweek Reset",
                "Write: one win, one friction point, one priority for the next 48 hours",
                60,
                manual = true
            )
        } else if (date.dayOfWeek == DayOfWeek.SUNDAY) {
            quests += QuestDefinition(
                "cardio",
                "35–45 Minutes Easy Cardio",
                "Build your aerobic base without interfering with tomorrow's lifting",
                80,
                manual = true
            )
            quests += QuestDefinition(
                "mindset",
                "Weekly Review + Plan",
                "Review the week, choose three priorities, and schedule the hardest one first",
                80,
                manual = true
            )
        } else {
            quests += QuestDefinition(
                "mobility",
                "10-Minute Mobility Protocol",
                "Hips, thoracic spine, shoulders, and ankles",
                60,
                manual = true
            )
        }

        quests += listOf(
            QuestDefinition("protein", "Hit ${targets.proteinGrams} g Protein", "Daily muscle-building baseline", 80),
            QuestDefinition("calories", "Hit Lean-Gain Calories", "Stay within ±10% of ${targets.calories} kcal", 60),
            QuestDefinition("steps", "Reach ${targets.steps} Steps", "Low-fatigue movement and recovery", 50),
            QuestDefinition(
                "sleep",
                "Sleep ${state.settings.sleepTargetHours.toInt()}+ Hours",
                "Bonus XP for giving recovery enough time",
                40,
                core = false
            ),
            QuestDefinition("weight", "Log Morning Weight", "Trend data, not a judgment", 25, core = false)
        )

        val active = state.activeChallenge
        val definition = active?.let { ChallengeLibrary.byId(it.challengeId) }
        if (active != null && definition != null) {
            quests += QuestDefinition(
                "challenge_reading",
                "Read ${definition.dailyMinutes} min: ${definition.title}",
                "Challenge progress ${active.progressDates.size}/${definition.durationDays} days",
                40,
                core = false
            )
        }

        return quests
    }

    fun completedQuestIds(date: LocalDate, state: AppState = _state.value): Set<String> =
        state.questCompletions[date.toString()] ?: emptySet()

    fun pendingMissedDates(today: LocalDate, state: AppState = _state.value): List<LocalDate> {
        val last = state.lastSealedDate?.let { runCatching { LocalDate.parse(it) }.getOrNull() } ?: return emptyList()
        if (!last.isBefore(today.minusDays(1))) return emptyList()
        val protected = state.protectedDates
        val result = mutableListOf<LocalDate>()
        var d = last.plusDays(1)
        while (d.isBefore(today)) {
            if (d.toString() !in protected) result += d
            d = d.plusDays(1)
        }
        return result
    }

    fun challengeLibrary(): List<ChallengeDefinition> = ChallengeLibrary.books

    fun activeChallengeDefinition(state: AppState = _state.value): ChallengeDefinition? =
        state.activeChallenge?.let { ChallengeLibrary.byId(it.challengeId) }

    fun startChallenge(challengeId: String, date: LocalDate) = mutate { state ->
        val definition = ChallengeLibrary.byId(challengeId)
        if (definition == null || state.activeChallenge != null) state
        else state.copy(
            activeChallenge = ActiveChallenge(
                challengeId = definition.id,
                startedOn = date.toString()
            )
        )
    }

    fun completeChallengeSession(date: LocalDate) = mutate { state ->
        val active = state.activeChallenge ?: return@mutate state
        val definition = ChallengeLibrary.byId(active.challengeId) ?: return@mutate state
        val dateKey = date.toString()
        if (dateKey in active.progressDates) return@mutate state

        var next = syncQuest(state, date, "challenge_reading", shouldComplete = true)
        val updatedDates = active.progressDates + dateKey
        if (updatedDates.size >= definition.durationDays) {
            next.copy(
                xp = next.xp + definition.completionXp,
                activeChallenge = null,
                completedChallenges = next.completedChallenges + definition.id
            )
        } else {
            next.copy(activeChallenge = active.copy(progressDates = updatedDates))
        }
    }

    fun abandonChallenge() = mutate { state -> state.copy(activeChallenge = null) }

    fun saveCheckIn(date: LocalDate, sleepHours: Float, soreness: Int, sharpPain: Boolean) = mutate { state ->
        val key = date.toString()
        val safeSleep = sleepHours.coerceIn(0f, 14f)
        val log = (state.logs[key] ?: DailyLog()).copy(
            checkInSaved = true,
            sleepHours = safeSleep,
            soreness = soreness.coerceIn(0, 10),
            sharpPain = sharpPain
        )
        var next = state.copy(logs = state.logs + (key to log))
        next = syncQuest(next, date, "checkin", shouldComplete = true)
        syncQuest(next, date, "sleep", shouldComplete = safeSleep >= state.settings.sleepTargetHours)
    }

    fun saveNutrition(date: LocalDate, calories: Int, proteinGrams: Int) = mutate { state ->
        val key = date.toString()
        val log = (state.logs[key] ?: DailyLog()).copy(
            calories = calories.coerceAtLeast(0),
            proteinGrams = proteinGrams.coerceAtLeast(0)
        )
        var next = state.copy(logs = state.logs + (key to log))
        next = syncQuest(next, date, "protein", proteinGrams >= state.settings.nutrition.proteinGrams)
        val target = state.settings.nutrition.calories
        val calorieHit = calories in (target * 0.90).toInt()..(target * 1.10).toInt()
        syncQuest(next, date, "calories", calorieHit)
    }

    fun saveSteps(date: LocalDate, steps: Int) = mutate { state ->
        val key = date.toString()
        val log = (state.logs[key] ?: DailyLog()).copy(steps = steps.coerceAtLeast(0))
        val next = state.copy(logs = state.logs + (key to log))
        syncQuest(next, date, "steps", steps >= state.settings.nutrition.steps)
    }

    fun saveWeight(date: LocalDate, weightLb: Float) = mutate { state ->
        val key = date.toString()
        val log = (state.logs[key] ?: DailyLog()).copy(weightLb = weightLb.takeIf { it > 0f })
        val next = state.copy(logs = state.logs + (key to log))
        syncQuest(next, date, "weight", weightLb > 0f)
    }

    fun toggleManualQuest(date: LocalDate, questId: String) = mutate { state ->
        val definition = questsFor(date, state).firstOrNull { it.id == questId } ?: return@mutate state
        if (!definition.manual) return@mutate state
        val current = completedQuestIds(date, state)
        val shouldComplete = questId !in current
        syncQuest(state, date, questId, shouldComplete)
    }

    fun useRevivalStone(today: LocalDate) = mutate { state ->
        val normalized = normalizeMonth(state)
        val pending = pendingMissedDates(today, normalized)
        if (normalized.revivalStones <= 0 || pending.isEmpty()) normalized
        else normalized.copy(
            revivalStones = normalized.revivalStones - 1,
            protectedDates = normalized.protectedDates + pending.first().toString()
        )
    }

    private fun syncQuest(state: AppState, date: LocalDate, questId: String, shouldComplete: Boolean): AppState {
        val quests = questsFor(date, state)
        val definition = quests.firstOrNull { it.id == questId } ?: return state
        val key = date.toString()
        val current = state.questCompletions[key] ?: emptySet()
        val already = questId in current
        if (already == shouldComplete) return maybeSealDay(state, date)

        val updatedSet = if (shouldComplete) current + questId else current - questId
        val nextXp = (state.xp + if (shouldComplete) definition.xp else -definition.xp).coerceAtLeast(0)
        val updatedMap = if (updatedSet.isEmpty()) state.questCompletions - key else state.questCompletions + (key to updatedSet)
        return maybeSealDay(state.copy(xp = nextXp, questCompletions = updatedMap), date)
    }

    private fun maybeSealDay(state: AppState, date: LocalDate): AppState {
        if (state.lastSealedDate == date.toString()) return state
        val coreIds = questsFor(date, state).filter { it.core }.map { it.id }.toSet()
        val completed = completedQuestIds(date, state)
        if (!completed.containsAll(coreIds)) return state

        val last = state.lastSealedDate?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        val missed = if (last == null) emptyList() else {
            val result = mutableListOf<LocalDate>()
            var d = last.plusDays(1)
            while (d.isBefore(date)) {
                if (d.toString() !in state.protectedDates) result += d
                d = d.plusDays(1)
            }
            result
        }
        val newStreak = if (last == null || missed.isNotEmpty()) 1 else state.streak + 1
        return state.copy(
            streak = newStreak,
            lastSealedDate = date.toString(),
            protectedDates = emptySet()
        )
    }

    private fun normalizeMonth(state: AppState): AppState {
        val month = YearMonth.now().toString()
        return if (state.revivalMonth == month) state
        else state.copy(
            revivalStones = state.settings.monthlyRevivalStones,
            revivalMonth = month,
            protectedDates = emptySet()
        )
    }

    private fun mutate(block: (AppState) -> AppState) {
        scope.launch {
            val normalized = normalizeMonth(_state.value)
            val next = normalizeMonth(block(normalized))
            _state.value = next
            persist(next)
        }
    }

    private suspend fun persist(state: AppState) {
        context.ascensionDataStore.edit { prefs ->
            prefs[stateKey] = json.encodeToString(state)
        }
    }
}
