package com.ascension.personal.model

import java.time.DayOfWeek
import java.time.LocalDate

object WorkoutPlan {
    private val upperStrength = WorkoutDay(
        title = "Upper Strength",
        focus = "Heavy compounds + upper-body strength",
        exercises = listOf(
            Exercise("Barbell Bench Press", 4, "3–5", "2–3 min rest"),
            Exercise("Weighted Pull-up / Chin-up", 4, "4–6", "2–3 min rest"),
            Exercise("Overhead Press", 3, "4–6", "2–3 min rest"),
            Exercise("Chest-Supported Row", 3, "5–8", "2 min rest"),
            Exercise("Incline Dumbbell Press", 2, "8–10", "1–2 RIR"),
            Exercise("Lateral Raise", 3, "12–20", "Controlled reps")
        )
    )

    private val lowerStrength = WorkoutDay(
        title = "Lower Strength",
        focus = "Squat strength + posterior chain",
        exercises = listOf(
            Exercise("Back Squat", 4, "3–5", "2–4 min rest"),
            Exercise("Romanian Deadlift", 3, "5–8", "Controlled eccentric"),
            Exercise("Bulgarian Split Squat", 3, "6–10 / leg"),
            Exercise("Leg Curl", 3, "8–12"),
            Exercise("Standing Calf Raise", 4, "8–15"),
            Exercise("Ab Wheel", 3, "8–15")
        )
    )

    private val recoveryMobility = WorkoutDay(
        title = "Recovery / Mobility",
        focus = "Low-fatigue conditioning, mobility, and nervous-system recovery",
        exercises = listOf(
            Exercise("Zone 2 Cardio / Brisk Walk", 1, "30–40 min", "Easy enough to speak in sentences"),
            Exercise("90/90 Hip Switches", 2, "6–8 / side", "Smooth, pain-free range"),
            Exercise("Half-Kneeling Hip Flexor Stretch", 2, "30–45 sec / side", "Glute lightly engaged"),
            Exercise("Thoracic Open Books", 2, "6–8 / side", "Slow exhale at end range"),
            Exercise("Wall Slides", 2, "8–12", "Keep ribs controlled"),
            Exercise("Ankle Knee-to-Wall", 2, "8–10 / side", "Heel stays down")
        ),
        recoveryDay = true
    )

    private val backDeltsTraps = WorkoutDay(
        title = "Back / Delts / Traps",
        focus = "Width, upper-back density, shoulders and grip",
        exercises = listOf(
            Exercise("Pull-up / Lat Pulldown", 3, "6–10"),
            Exercise("Chest-Supported / Cable Row", 3, "8–12"),
            Exercise("Straight-Arm Pulldown", 2, "10–15"),
            Exercise("Lateral Raise", 4, "12–20"),
            Exercise("Rear-Delt Fly", 3, "12–20"),
            Exercise("Shrug", 3, "8–12"),
            Exercise("Hammer Curl", 3, "8–12"),
            Exercise("Farmer Carry", 3, "30–60 sec")
        )
    )

    private val chestArms = WorkoutDay(
        title = "Chest / Arms",
        focus = "Upper chest, arms and shoulder cap",
        exercises = listOf(
            Exercise("Incline Barbell Press", 3, "5–8"),
            Exercise("Dumbbell / Machine Press", 3, "8–12"),
            Exercise("Dips", 2, "6–10"),
            Exercise("Cable Fly", 2, "12–20"),
            Exercise("Curl", 3, "8–12"),
            Exercise("Overhead Triceps Extension", 3, "10–15"),
            Exercise("Preacher Curl", 2, "10–15"),
            Exercise("Pressdown", 2, "10–15"),
            Exercise("Lateral Raise", 3, "15–25")
        )
    )

    private val legsDeadlift = WorkoutDay(
        title = "Legs / Deadlift",
        focus = "Deadlift strength + quad/hamstring hypertrophy",
        exercises = listOf(
            Exercise("Deadlift / Trap-Bar Deadlift", 3, "2–4", "No grinders"),
            Exercise("Front Squat / Hack Squat", 3, "6–10"),
            Exercise("Leg Extension", 3, "10–15"),
            Exercise("Seated Leg Curl", 3, "10–15"),
            Exercise("Calf Raise", 4, "10–20"),
            Exercise("Hanging Leg Raise", 3, "10–15")
        )
    )

    private val weeklyReset = WorkoutDay(
        title = "Cardio / Weekly Reset",
        focus = "Build an aerobic base, restore range of motion, and prepare the next week",
        exercises = listOf(
            Exercise("Easy Cardio", 1, "35–45 min", "Walk, incline treadmill, bike, or elliptical"),
            Exercise("Deep Squat Hold", 2, "30–60 sec", "Use support if needed"),
            Exercise("90/90 Hip Flow", 2, "6–8 / side"),
            Exercise("Thoracic Rotation", 2, "6–8 / side"),
            Exercise("Dead Hang", 2, "20–40 sec", "Optional and pain-free only"),
            Exercise("Easy Neck Range of Motion", 1, "3–5 each direction", "No loaded neck bridges")
        ),
        recoveryDay = true
    )

    fun forDate(date: LocalDate): WorkoutDay = when (date.dayOfWeek) {
        DayOfWeek.MONDAY -> upperStrength
        DayOfWeek.TUESDAY -> lowerStrength
        DayOfWeek.WEDNESDAY -> recoveryMobility
        DayOfWeek.THURSDAY -> backDeltsTraps
        DayOfWeek.FRIDAY -> chestArms
        DayOfWeek.SATURDAY -> legsDeadlift
        DayOfWeek.SUNDAY -> weeklyReset
    }
}
