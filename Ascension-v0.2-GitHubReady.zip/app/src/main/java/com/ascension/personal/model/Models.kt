package com.ascension.personal.model

import kotlinx.serialization.Serializable

@Serializable
data class NutritionTargets(
    val calories: Int = 2700,
    val proteinGrams: Int = 150,
    val carbsGrams: Int = 365,
    val fatGrams: Int = 70,
    val steps: Int = 8000
)

@Serializable
data class UserSettings(
    val startingWeightLb: Float = 144f,
    val nutrition: NutritionTargets = NutritionTargets(),
    val monthlyRevivalStones: Int = 2,
    val sleepTargetHours: Float = 7f
)

@Serializable
data class DailyLog(
    val checkInSaved: Boolean = false,
    val sleepHours: Float = 7.5f,
    val soreness: Int = 3,
    val sharpPain: Boolean = false,
    val calories: Int = 0,
    val proteinGrams: Int = 0,
    val steps: Int = 0,
    val weightLb: Float? = null
)

@Serializable
data class ActiveChallenge(
    val challengeId: String,
    val startedOn: String,
    val progressDates: Set<String> = emptySet()
)

@Serializable
data class AppState(
    val xp: Int = 0,
    val streak: Int = 0,
    val revivalStones: Int = 2,
    val revivalMonth: String = "",
    val lastSealedDate: String? = null,
    val protectedDates: Set<String> = emptySet(),
    val questCompletions: Map<String, Set<String>> = emptyMap(),
    val logs: Map<String, DailyLog> = emptyMap(),
    val activeChallenge: ActiveChallenge? = null,
    val completedChallenges: Set<String> = emptySet(),
    val settings: UserSettings = UserSettings()
)

enum class ReadinessMode {
    UNASSESSED,
    NORMAL,
    CAUTION,
    RECOVERY
}

data class Readiness(
    val mode: ReadinessMode,
    val score: Int,
    val headline: String,
    val guidance: String
)

data class QuestDefinition(
    val id: String,
    val title: String,
    val subtitle: String,
    val xp: Int,
    val core: Boolean = true,
    val manual: Boolean = false
)

data class ChallengeDefinition(
    val id: String,
    val title: String,
    val author: String,
    val category: String,
    val durationDays: Int,
    val dailyMinutes: Int,
    val completionXp: Int,
    val why: String
)

data class Exercise(
    val name: String,
    val sets: Int,
    val reps: String,
    val note: String = ""
)

data class WorkoutDay(
    val title: String,
    val focus: String,
    val exercises: List<Exercise>,
    val recoveryDay: Boolean = false
)
