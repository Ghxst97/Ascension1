package com.ascension.personal.model

object ChallengeLibrary {
    val books: List<ChallengeDefinition> = listOf(
        ChallengeDefinition(
            id = "atomic_habits",
            title = "Atomic Habits",
            author = "James Clear",
            category = "Habits & Systems",
            durationDays = 14,
            dailyMinutes = 20,
            completionXp = 900,
            why = "Build repeatable systems for behavior change instead of relying on motivation."
        ),
        ChallengeDefinition(
            id = "mans_search_for_meaning",
            title = "Man's Search for Meaning",
            author = "Viktor E. Frankl",
            category = "Meaning & Resilience",
            durationDays = 7,
            dailyMinutes = 20,
            completionXp = 700,
            why = "A short, serious challenge in meaning, responsibility, and resilience."
        ),
        ChallengeDefinition(
            id = "how_to_win_friends",
            title = "How to Win Friends and Influence People",
            author = "Dale Carnegie",
            category = "Communication",
            durationDays = 14,
            dailyMinutes = 20,
            completionXp = 900,
            why = "Practice better listening, social awareness, and relationship skills."
        ),
        ChallengeDefinition(
            id = "meditations",
            title = "Meditations",
            author = "Marcus Aurelius",
            category = "Self-Mastery",
            durationDays = 14,
            dailyMinutes = 15,
            completionXp = 850,
            why = "Train perspective, emotional restraint, duty, and control over your own actions."
        ),
        ChallengeDefinition(
            id = "psychology_of_money",
            title = "The Psychology of Money",
            author = "Morgan Housel",
            category = "Money & Decisions",
            durationDays = 14,
            dailyMinutes = 20,
            completionXp = 900,
            why = "Improve long-term thinking around risk, wealth, behavior, and financial decisions."
        ),
        ChallengeDefinition(
            id = "deep_work",
            title = "Deep Work",
            author = "Cal Newport",
            category = "Focus",
            durationDays = 14,
            dailyMinutes = 20,
            completionXp = 900,
            why = "Build the ability to focus deeply and produce meaningful work without constant distraction."
        ),
        ChallengeDefinition(
            id = "scout_mindset",
            title = "The Scout Mindset",
            author = "Julia Galef",
            category = "Clear Thinking",
            durationDays = 14,
            dailyMinutes = 20,
            completionXp = 950,
            why = "Practice seeing reality more accurately instead of defending what you want to believe."
        ),
        ChallengeDefinition(
            id = "make_it_stick",
            title = "Make It Stick",
            author = "Peter C. Brown, Henry L. Roediger III, Mark A. McDaniel",
            category = "Learning",
            durationDays = 14,
            dailyMinutes = 20,
            completionXp = 950,
            why = "Use evidence-based learning methods such as retrieval, spacing, and interleaving."
        )
    )

    fun byId(id: String): ChallengeDefinition? = books.firstOrNull { it.id == id }
}
