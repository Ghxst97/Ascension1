package com.ascension.personal.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ascension.personal.data.AscensionRepository
import com.ascension.personal.model.AppState
import com.ascension.personal.model.ChallengeDefinition
import com.ascension.personal.model.DailyLog
import com.ascension.personal.model.Exercise
import com.ascension.personal.model.QuestDefinition
import com.ascension.personal.model.Readiness
import com.ascension.personal.model.ReadinessMode
import com.ascension.personal.model.WorkoutPlan
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import kotlin.math.max
import kotlin.math.min

private enum class Screen(val label: String, val icon: ImageVector) {
    SYSTEM("System", Icons.Default.Home),
    TRAINING("Training", Icons.Default.FitnessCenter),
    CHALLENGES("Quests", Icons.Default.AutoStories),
    CHARACTER("Character", Icons.Default.Person),
    PROGRESS("Progress", Icons.Default.ShowChart)
}

private fun levelForXp(xp: Int): Int = 1 + (xp / 500)
private fun xpIntoLevel(xp: Int): Int = xp % 500
private fun rankForLevel(level: Int): String = when {
    level >= 75 -> "S"
    level >= 50 -> "A"
    level >= 35 -> "B"
    level >= 20 -> "C"
    level >= 10 -> "D"
    else -> "E"
}

@Composable
fun AscensionApp(repository: AscensionRepository) {
    val state by repository.state.collectAsState()
    var screen by remember { mutableStateOf(Screen.SYSTEM) }
    val today = remember { LocalDate.now() }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                Screen.entries.forEach { item ->
                    NavigationBarItem(
                        selected = screen == item,
                        onClick = { screen = item },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) }
                    )
                }
            }
        }
    ) { padding ->
        when (screen) {
            Screen.SYSTEM -> SystemScreen(state, repository, today, padding)
            Screen.TRAINING -> TrainingScreen(state, repository, today, padding)
            Screen.CHALLENGES -> ChallengeScreen(state, repository, today, padding)
            Screen.CHARACTER -> CharacterScreen(state, padding)
            Screen.PROGRESS -> ProgressScreen(state, padding)
        }
    }
}

@Composable
private fun SystemScreen(
    state: AppState,
    repository: AscensionRepository,
    today: LocalDate,
    padding: PaddingValues
) {
    val readiness = repository.readiness(today, state)
    val quests = repository.questsFor(today, state)
    val completed = repository.completedQuestIds(today, state)
    val pendingMisses = repository.pendingMissedDates(today, state)

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .padding(padding)
    ) {
        val expanded = maxWidth >= 700.dp
        if (expanded) {
            Row(
                Modifier.fillMaxSize().padding(18.dp),
                horizontalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                LazyColumn(
                    Modifier.weight(1f).fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    item { HeaderCard(state, today) }
                    if (pendingMisses.isNotEmpty()) {
                        item { RevivalCard(state, pendingMisses.size) { repository.useRevivalStone(today) } }
                    }
                    item { ReadinessCard(readiness) }
                    item {
                        CheckInCard(state.logs[today.toString()] ?: DailyLog()) { sleep, soreness, pain ->
                            repository.saveCheckIn(today, sleep, soreness, pain)
                        }
                    }
                    item { SectionTitle("DAILY QUESTS") }
                    items(quests) { quest ->
                        QuestCard(
                            quest = quest,
                            completed = quest.id in completed,
                            onToggle = { repository.toggleManualQuest(today, quest.id) }
                        )
                    }
                }

                LazyColumn(
                    Modifier.weight(1f).fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    item { NutritionCard(state, today, repository) }
                    if (state.activeChallenge != null) {
                        item { ChallengeDailyCard(state, repository, today) }
                    }
                    item { AvatarCard(state) }
                    item { SafetyCard() }
                }
            }
        } else {
            LazyColumn(
                Modifier.fillMaxSize().padding(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp)
            ) {
                item { HeaderCard(state, today) }
                if (pendingMisses.isNotEmpty()) {
                    item { RevivalCard(state, pendingMisses.size) { repository.useRevivalStone(today) } }
                }
                item { ReadinessCard(readiness) }
                item {
                    CheckInCard(state.logs[today.toString()] ?: DailyLog()) { sleep, soreness, pain ->
                        repository.saveCheckIn(today, sleep, soreness, pain)
                    }
                }
                item { NutritionCard(state, today, repository) }
                if (state.activeChallenge != null) {
                    item { ChallengeDailyCard(state, repository, today) }
                }
                item { SectionTitle("DAILY QUESTS") }
                items(quests) { quest ->
                    QuestCard(
                        quest = quest,
                        completed = quest.id in completed,
                        onToggle = { repository.toggleManualQuest(today, quest.id) }
                    )
                }
                item { SafetyCard() }
            }
        }
    }
}

@Composable
private fun HeaderCard(state: AppState, today: LocalDate) {
    val level = levelForXp(state.xp)
    val rank = rankForLevel(level)
    val current = xpIntoLevel(state.xp)
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("ASCENSION // AWAKENING", fontSize = 12.sp, color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.Bold)
            Text("LUKE — LEVEL $level", fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text("RANK $rank  •  ${today.format(DateTimeFormatter.ofPattern("EEEE, MMM d"))}", color = MaterialTheme.colorScheme.onPrimaryContainer)
            LinearProgressIndicator(
                progress = { current / 500f },
                modifier = Modifier.fillMaxWidth().height(7.dp)
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("$current / 500 XP")
                Text("🔥 ${state.streak} day streak", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun RevivalCard(state: AppState, missedDays: Int, onUse: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("STREAK FRACTURE DETECTED", fontWeight = FontWeight.Black)
            Text("$missedDays missed day${if (missedDays == 1) "" else "s"} can break your active streak. One Revival Stone protects one missed day without awarding free XP.")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("◆ ${state.revivalStones} Revival Stones", color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.Bold)
                Button(onClick = onUse, enabled = state.revivalStones > 0) { Text("USE STONE") }
            }
        }
    }
}

@Composable
private fun ReadinessCard(readiness: Readiness) {
    val label = when (readiness.mode) {
        ReadinessMode.NORMAL -> "GREEN"
        ReadinessMode.CAUTION -> "YELLOW"
        ReadinessMode.RECOVERY -> "REDIRECT"
        ReadinessMode.UNASSESSED -> "UNKNOWN"
    }
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("READINESS // $label", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                    Text(readiness.headline, fontSize = 22.sp, fontWeight = FontWeight.Black)
                }
                if (readiness.mode != ReadinessMode.UNASSESSED) {
                    Text("${readiness.score}%", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
            }
            Text(readiness.guidance, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun CheckInCard(log: DailyLog, onSave: (Float, Int, Boolean) -> Unit) {
    var sleep by remember(log.sleepHours) { mutableFloatStateOf(log.sleepHours) }
    var soreness by remember(log.soreness) { mutableIntStateOf(log.soreness) }
    var pain by remember(log.sharpPain) { mutableStateOf(log.sharpPain) }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionTitle("PRE-WORKOUT CHECK-IN")
            Text("Sleep: ${"%.1f".format(sleep)} h", fontWeight = FontWeight.SemiBold)
            Slider(value = sleep, onValueChange = { sleep = it }, valueRange = 3f..10f, steps = 13)
            Text("Whole-body soreness: $soreness / 10", fontWeight = FontWeight.SemiBold)
            Slider(value = soreness.toFloat(), onValueChange = { soreness = it.toInt() }, valueRange = 0f..10f, steps = 9)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Sharp / joint / injury-like pain")
                    Text("Different from normal muscle soreness", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = pain, onCheckedChange = { pain = it })
            }
            Button(onClick = { onSave(sleep, soreness, pain) }, modifier = Modifier.fillMaxWidth()) {
                Text(if (log.checkInSaved) "UPDATE READINESS" else "SET TODAY'S READINESS")
            }
        }
    }
}

@Composable
private fun NutritionCard(state: AppState, today: LocalDate, repository: AscensionRepository) {
    val targets = state.settings.nutrition
    val log = state.logs[today.toString()] ?: DailyLog()
    var calories by remember(log.calories) { mutableStateOf(if (log.calories == 0) "" else log.calories.toString()) }
    var protein by remember(log.proteinGrams) { mutableStateOf(if (log.proteinGrams == 0) "" else log.proteinGrams.toString()) }
    var steps by remember(log.steps) { mutableStateOf(if (log.steps == 0) "" else log.steps.toString()) }
    var weight by remember(log.weightLb) { mutableStateOf(log.weightLb?.toString() ?: "") }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionTitle("LEAN-GAIN FUEL")
            Text("${targets.calories} kcal  •  ${targets.proteinGrams} g protein  •  ${targets.carbsGrams} g carbs  •  ${targets.fatGrams} g fat", fontWeight = FontWeight.Bold)
            Text("Starting targets are intentionally moderate; the bodyweight trend should decide later calorie adjustments.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = calories,
                    onValueChange = { calories = it.filter(Char::isDigit).take(5) },
                    label = { Text("Calories") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedTextField(
                    value = protein,
                    onValueChange = { protein = it.filter(Char::isDigit).take(4) },
                    label = { Text("Protein g") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
            }
            Button(
                onClick = { repository.saveNutrition(today, calories.toIntOrNull() ?: 0, protein.toIntOrNull() ?: 0) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("LOG NUTRITION") }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = steps,
                    onValueChange = { steps = it.filter(Char::isDigit).take(6) },
                    label = { Text("Steps") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedButton(onClick = { repository.saveSteps(today, steps.toIntOrNull() ?: 0) }) { Text("SAVE") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = weight,
                    onValueChange = { value -> weight = value.filter { it.isDigit() || it == '.' }.take(6) },
                    label = { Text("Morning weight lb") },
                    modifier = Modifier.weight(1f),
                    singleLine = true
                )
                OutlinedButton(onClick = { weight.toFloatOrNull()?.let { repository.saveWeight(today, it) } }) { Text("SAVE") }
            }
        }
    }
}

@Composable
private fun QuestCard(quest: QuestDefinition, completed: Boolean, onToggle: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (completed) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f) else MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (quest.manual) {
                Checkbox(checked = completed, onCheckedChange = { onToggle() })
            } else {
                Icon(
                    Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = if (completed) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.outline,
                    modifier = Modifier.alpha(if (completed) 1f else 0.35f)
                )
            }
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(quest.title, fontWeight = FontWeight.Bold)
                    if (!quest.core) AssistChip(onClick = {}, label = { Text("BONUS") })
                }
                Text(quest.subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("+${quest.xp} XP", color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun TrainingScreen(state: AppState, repository: AscensionRepository, today: LocalDate, padding: PaddingValues) {
    val readiness = repository.readiness(today, state)
    val plan = WorkoutPlan.forDate(today)
    val completed = "training" in repository.completedQuestIds(today, state)

    LazyColumn(
        Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("TRAINING // ${plan.title.uppercase()}", fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text(plan.focus, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item { WeeklyProgramCard(today) }
        item { ReadinessCard(readiness) }

        if (readiness.mode == ReadinessMode.RECOVERY && !plan.recoveryDay) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("RECOVERY OVERRIDE", fontWeight = FontWeight.Black, fontSize = 22.sp)
                        Text("Today's heavy session is swapped for 20–30 min easy walking plus 10–20 min pain-free mobility. Completing the recovery replacement still awards the full training quest XP.")
                    }
                }
            }
        } else {
            items(plan.exercises) { exercise ->
                ExerciseCard(exercise, readiness, plan.recoveryDay)
            }
        }
        item {
            Button(
                onClick = { repository.toggleManualQuest(today, "training") },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (completed) "MARK SESSION INCOMPLETE" else "COMPLETE TODAY'S SESSION")
            }
        }
        if (!plan.recoveryDay) {
            item {
                Text(
                    "Double progression: when all prescribed sets reach the top of the rep range with clean form and about 1–2 RIR, add a small amount of load next time. Avoid constant 1RM testing.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun WeeklyProgramCard(today: LocalDate) {
    val monday = today.minusDays((today.dayOfWeek.value - 1).toLong())
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionTitle("7-DAY ASCENSION PROGRAM")
            repeat(7) { index ->
                val date = monday.plusDays(index.toLong())
                val day = WorkoutPlan.forDate(date)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(date.dayOfWeek.name.take(3), fontWeight = if (date == today) FontWeight.Black else FontWeight.SemiBold)
                    Text(day.title, color = if (date == today) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Text("Wednesday and Sunday are active-recovery days: cardio, mobility, and mental reset work instead of heavy lifting.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ExerciseCard(exercise: Exercise, readiness: Readiness, recoveryDay: Boolean) {
    val adjustedSets = if (!recoveryDay && readiness.mode == ReadinessMode.CAUTION) max(1, exercise.sets - 1) else exercise.sets
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(exercise.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                val extra = when {
                    recoveryDay -> ""
                    readiness.mode == ReadinessMode.CAUTION -> " • ~90% normal load • ~3 RIR"
                    readiness.mode == ReadinessMode.NORMAL -> " • 1–2 RIR on most work"
                    else -> ""
                }
                Text("$adjustedSets sets × ${exercise.reps}$extra", color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (exercise.note.isNotBlank()) Text(exercise.note, fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
            }
        }
    }
}

@Composable
private fun ChallengeScreen(state: AppState, repository: AscensionRepository, today: LocalDate, padding: PaddingValues) {
    val active = state.activeChallenge
    val activeDefinition = repository.activeChallengeDefinition(state)
    val library = repository.challengeLibrary()

    LazyColumn(
        Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 18.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("CHALLENGE QUESTS", fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text("Long-form quests build knowledge and perspective while the daily program builds your body and routines.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        if (active != null && activeDefinition != null) {
            item { ActiveChallengeCard(state, repository, activeDefinition, today) }
        } else {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("NO ACTIVE CHALLENGE", fontWeight = FontWeight.Black, fontSize = 20.sp)
                        Text("Choose one book below. You can progress once per day, so a 7-day challenge takes at least 7 days and a 14-day challenge takes at least 14.")
                    }
                }
            }
        }

        item { SectionTitle("SYSTEM LIBRARY") }
        items(library) { challenge ->
            ChallengeLibraryCard(
                challenge = challenge,
                isActive = active?.challengeId == challenge.id,
                isCompleted = challenge.id in state.completedChallenges,
                canStart = active == null && challenge.id !in state.completedChallenges,
                onStart = { repository.startChallenge(challenge.id, today) }
            )
        }
    }
}

@Composable
private fun ActiveChallengeCard(
    state: AppState,
    repository: AscensionRepository,
    definition: ChallengeDefinition,
    today: LocalDate
) {
    val active = state.activeChallenge ?: return
    val todayDone = today.toString() in active.progressDates
    val progress = active.progressDates.size.coerceAtMost(definition.durationDays)

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionTitle("ACTIVE CHALLENGE")
            Text(definition.title, fontSize = 24.sp, fontWeight = FontWeight.Black)
            Text("${definition.author} • ${definition.category}", color = MaterialTheme.colorScheme.tertiary)
            Text(definition.why)
            LinearProgressIndicator(
                progress = { progress / definition.durationDays.toFloat() },
                modifier = Modifier.fillMaxWidth().height(8.dp)
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("$progress / ${definition.durationDays} days", fontWeight = FontWeight.Bold)
                Text("+${definition.completionXp} completion XP", color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = { repository.completeChallengeSession(today) },
                enabled = !todayDone,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (todayDone) "TODAY'S READING COMPLETE" else "COMPLETE ${definition.dailyMinutes} MIN READING")
            }
            OutlinedButton(onClick = { repository.abandonChallenge() }, modifier = Modifier.fillMaxWidth()) {
                Text("ABANDON CHALLENGE")
            }
            Text("Each reading day also awards +40 XP. Abandoning has no punishment; it simply clears the active slot.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ChallengeDailyCard(state: AppState, repository: AscensionRepository, today: LocalDate) {
    val active = state.activeChallenge ?: return
    val definition = repository.activeChallengeDefinition(state) ?: return
    val todayDone = today.toString() in active.progressDates
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionTitle("BONUS QUEST")
            Text(definition.title, fontWeight = FontWeight.Black, fontSize = 20.sp)
            Text("${active.progressDates.size}/${definition.durationDays} reading days • ${definition.dailyMinutes} min today")
            Button(
                onClick = { repository.completeChallengeSession(today) },
                enabled = !todayDone,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (todayDone) "READING LOGGED" else "LOG TODAY'S READING")
            }
        }
    }
}

@Composable
private fun ChallengeLibraryCard(
    challenge: ChallengeDefinition,
    isActive: Boolean,
    isCompleted: Boolean,
    canStart: Boolean,
    onStart: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(challenge.title, fontWeight = FontWeight.Black, fontSize = 18.sp)
                    Text(challenge.author, color = MaterialTheme.colorScheme.secondary)
                }
                val badge = when {
                    isCompleted -> "CLEARED"
                    isActive -> "ACTIVE"
                    else -> "${challenge.durationDays} DAYS"
                }
                AssistChip(onClick = {}, label = { Text(badge) })
            }
            Text("${challenge.category} • ${challenge.dailyMinutes} min/day • +${challenge.completionXp} completion XP", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(challenge.why)
            if (!isCompleted) {
                OutlinedButton(onClick = onStart, enabled = canStart, modifier = Modifier.fillMaxWidth()) {
                    Text(if (isActive) "CURRENT CHALLENGE" else if (canStart) "START CHALLENGE" else "FINISH ACTIVE CHALLENGE FIRST")
                }
            }
        }
    }
}

@Composable
private fun CharacterScreen(state: AppState, padding: PaddingValues) {
    val level = levelForXp(state.xp)
    val rank = rankForLevel(level)
    val trainingCount = state.questCompletions.values.count { "training" in it }
    val mobilityCount = state.questCompletions.values.count { "mobility" in it }
    val cardioCount = state.questCompletions.values.count { "cardio" in it }
    val stepCount = state.questCompletions.values.count { "steps" in it }
    val checkinCount = state.questCompletions.values.count { "checkin" in it }
    val mindsetCount = state.questCompletions.values.count { "mindset" in it }
    val readingCount = state.questCompletions.values.count { "challenge_reading" in it }
    val attributes = listOf(
        "STR" to min(99, 10 + level + trainingCount * 2),
        "PHY" to min(99, 10 + level * 2 + trainingCount),
        "MOB" to min(99, 10 + mobilityCount * 2 + cardioCount),
        "END" to min(99, 10 + stepCount * 2 + cardioCount * 3),
        "REC" to min(99, 10 + checkinCount + cardioCount),
        "DIS" to min(99, 10 + state.streak * 3 + level + mindsetCount * 2 + readingCount)
    )

    LazyColumn(
        Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 18.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("AWAKENED AVATAR", fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Spacer(Modifier.height(8.dp))
                    CharacterSigil(level)
                    Spacer(Modifier.height(8.dp))
                    Text("LEVEL $level // RANK $rank", fontSize = 24.sp, fontWeight = FontWeight.Black)
                    Text(characterStage(level), color = MaterialTheme.colorScheme.tertiary)
                }
            }
        }
        item { SectionTitle("ATTRIBUTES") }
        items(attributes) { (name, value) ->
            AttributeRow(name, value)
        }
        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("EVOLUTION RULE", fontWeight = FontWeight.Black)
                    Text("Your avatar grows from actual consistency: training, mobility, conditioning, recovery decisions, nutrition, mental resets, reading challenges, and streaks. No XP farming through unsafe extra workouts.")
                }
            }
        }
    }
}

@Composable
private fun CharacterSigil(level: Int) {
    val aura = min(1f, 0.25f + level / 80f)
    val primary = MaterialTheme.colorScheme.primary
    val tertiary = MaterialTheme.colorScheme.tertiary
    Canvas(modifier = Modifier.size(220.dp)) {
        val c = center
        drawCircle(primary.copy(alpha = 0.10f + aura * 0.12f), radius = size.minDimension * 0.47f, center = c)
        drawCircle(tertiary.copy(alpha = 0.20f + aura * 0.35f), radius = size.minDimension * 0.40f, center = c, style = Stroke(width = 5f))
        drawCircle(primary.copy(alpha = 0.40f), radius = size.minDimension * 0.31f, center = c, style = Stroke(width = 2f))
        drawCircle(Color(0xFFDCE8FF), radius = size.minDimension * 0.085f, center = Offset(c.x, c.y - size.height * 0.12f))
        drawRoundRect(
            color = Color(0xFF1B2A44),
            topLeft = Offset(c.x - size.width * 0.115f, c.y - size.height * 0.03f),
            size = Size(size.width * 0.23f, size.height * 0.28f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(28f, 28f)
        )
        val path = Path().apply {
            moveTo(c.x - size.width * 0.18f, c.y + size.height * 0.03f)
            lineTo(c.x, c.y + size.height * 0.12f)
            lineTo(c.x + size.width * 0.18f, c.y + size.height * 0.03f)
        }
        drawPath(path, tertiary.copy(alpha = 0.55f), style = Stroke(width = 8f))
    }
}

private fun characterStage(level: Int): String = when {
    level >= 75 -> "Sovereign Form"
    level >= 50 -> "Ascendant Form"
    level >= 35 -> "Vanguard Form"
    level >= 20 -> "Awakened Form"
    level >= 10 -> "Initiate Form"
    else -> "Dormant Form"
}

@Composable
private fun AttributeRow(name: String, value: Int) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(name, fontWeight = FontWeight.Black)
                Text(value.toString(), color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Black)
            }
            LinearProgressIndicator(progress = { value / 100f }, modifier = Modifier.fillMaxWidth().height(6.dp))
        }
    }
}

@Composable
private fun ProgressScreen(state: AppState, padding: PaddingValues) {
    val sortedWeights = state.logs.entries
        .filter { it.value.weightLb != null }
        .sortedByDescending { it.key }
        .take(14)
    val level = levelForXp(state.xp)
    val questsDone = state.questCompletions.values.sumOf { it.size }
    val workoutsDone = state.questCompletions.values.count { "training" in it }

    LazyColumn(
        Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 18.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Text("PROGRESS // RECORD", fontSize = 28.sp, fontWeight = FontWeight.Black) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("LEVEL", level.toString(), Modifier.weight(1f))
                StatTile("QUESTS", questsDone.toString(), Modifier.weight(1f))
                StatTile("SESSIONS", workoutsDone.toString(), Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("STREAK", state.streak.toString(), Modifier.weight(1f))
                StatTile("BOOKS", state.completedChallenges.size.toString(), Modifier.weight(1f))
                StatTile("STONES", state.revivalStones.toString(), Modifier.weight(1f))
            }
        }
        item { SectionTitle("BODYWEIGHT LOG") }
        if (sortedWeights.isEmpty()) {
            item { Text("No bodyweight entries yet. Log morning weight from the System screen.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        } else {
            items(sortedWeights) { entry ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(entry.key)
                        Text("${"%.1f".format(entry.value.weightLb)} lb", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("LEAN-GAIN TARGET", fontWeight = FontWeight.Black)
                    Text("Aim for a slow upward trend, roughly 0.1–0.25% of bodyweight per week. If the 2–3 week trend is flat, increase calories modestly; if it rises too quickly, reduce slightly.")
                }
            }
        }
    }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier) {
        Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun AvatarCard(state: AppState) {
    val level = levelForXp(state.xp)
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            SectionTitle("CHARACTER EVOLUTION")
            CharacterSigil(level)
            Text(characterStage(level), fontSize = 20.sp, fontWeight = FontWeight.Black)
            Text("Level $level • Rank ${rankForLevel(level)}", color = MaterialTheme.colorScheme.secondary)
        }
    }
}

@Composable
private fun SafetyCard() {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("SYSTEM SAFETY RULE", fontWeight = FontWeight.Black)
            Text("Low sleep and high soreness reduce training stress; sharp or injury-like pain redirects heavy training to recovery. Missed quests never trigger punishment workouts, food restriction, or unsafe volume.")
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, fontSize = 12.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.secondary, letterSpacing = 1.4.sp)
}
